# WordPress MySQL database migration
#
# Generated: Sunday 2. January 2022 11:15 UTC
# Hostname: localhost
# Database: `privatemarket`
# URL: http://privatemarket.io
# Path: /
# Tables: wp_cmplz_cookiebanners, wp_cmplz_cookies, wp_cmplz_services, wp_commentmeta, wp_comments, wp_email_log, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_tm_taskmeta, wp_tm_tasks, wp_usermeta, wp_users, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, customize_changeset, nav_menu_item, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cmplz_cookiebanners`
#

DROP TABLE IF EXISTS `wp_cmplz_cookiebanners`;


#
# Table structure of table `wp_cmplz_cookiebanners`
#

CREATE TABLE `wp_cmplz_cookiebanners` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `banner_version` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  `archived` int(11) NOT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `position` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `theme` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `checkbox_style` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `revoke` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `header` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dismiss` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `save_preferences` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `view_preferences` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `accept_all` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category_functional` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category_all` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category_stats` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category_prefs` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `accept` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message_optin` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `readmore_optin` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `use_categories` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tagmanager_categories` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `use_categories_optinstats` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hide_revoke` int(11) NOT NULL,
  `disable_cookiebanner` int(11) NOT NULL,
  `banner_width` int(11) NOT NULL,
  `soft_cookiewall` int(11) NOT NULL,
  `dismiss_on_scroll` int(11) NOT NULL,
  `dismiss_on_timeout` int(11) NOT NULL,
  `dismiss_timeout` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `accept_informational` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message_optout` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `readmore_optout` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `readmore_optout_dnsmpi` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `readmore_privacy` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `readmore_impressum` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `use_custom_cookie_css` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `custom_css` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `statistics` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_background` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_text` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_toggles` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_border_radius` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `border_width` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_button_accept` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_button_deny` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `colorpalette_button_settings` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `buttons_border_radius` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `animation` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `use_box_shadow` int(11) NOT NULL,
  `hide_preview` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_cmplz_cookiebanners`
#

#
# End of data contents of table `wp_cmplz_cookiebanners`
# --------------------------------------------------------



#
# Delete any existing table `wp_cmplz_cookies`
#

DROP TABLE IF EXISTS `wp_cmplz_cookies`;


#
# Table structure of table `wp_cmplz_cookies`
#

CREATE TABLE `wp_cmplz_cookies` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sync` int(11) NOT NULL,
  `ignored` int(11) NOT NULL,
  `retention` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `serviceID` int(11) NOT NULL,
  `cookieFunction` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `collectedPersonalData` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `purpose` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `language` varchar(6) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `isTranslationFrom` int(11) NOT NULL,
  `isPersonalData` int(11) NOT NULL,
  `isOwnDomainCookie` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `isMembersOnly` int(11) NOT NULL,
  `showOnPolicy` int(11) NOT NULL,
  `lastUpdatedDate` int(11) NOT NULL,
  `lastAddDate` int(11) NOT NULL,
  `firstAddDate` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_cmplz_cookies`
#

#
# End of data contents of table `wp_cmplz_cookies`
# --------------------------------------------------------



#
# Delete any existing table `wp_cmplz_services`
#

DROP TABLE IF EXISTS `wp_cmplz_services`;


#
# Table structure of table `wp_cmplz_services`
#

CREATE TABLE `wp_cmplz_services` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `serviceType` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `thirdParty` int(11) NOT NULL,
  `sharesData` int(11) NOT NULL,
  `secondParty` int(11) NOT NULL,
  `privacyStatementURL` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `language` varchar(6) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `isTranslationFrom` int(11) NOT NULL,
  `sync` int(11) NOT NULL,
  `lastUpdatedDate` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_cmplz_services`
#

#
# End of data contents of table `wp_cmplz_services`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un commentatore di WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-12-26 22:37:37', '2021-12-26 21:37:37', 'Ciao, questo è un commento.\nPer iniziare a moderare, modificare ed eliminare commenti, visita la schermata commenti nella bacheca.\nGli avatar di chi lascia un commento sono forniti da <a href="https://it.gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_email_log`
#

DROP TABLE IF EXISTS `wp_email_log`;


#
# Table structure of table `wp_email_log`
#

CREATE TABLE `wp_email_log` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `to_email` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `subject` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attachments` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sent_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attachment_name` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip_address` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `result` tinyint(1) DEFAULT NULL,
  `error_message` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_email_log`
#
INSERT INTO `wp_email_log` ( `id`, `to_email`, `subject`, `message`, `headers`, `attachments`, `sent_date`, `attachment_name`, `ip_address`, `result`, `error_message`) VALUES
(1, 'grgrzz008@gmail.com', '[Private Maket] Aggiornamento in background completato', 'Sito WordPress: http://privatemarket.io/\nSUCCESSO: WordPress è stato correttamente aggiornato alla versione WordPress 5.9-beta4-52422\n\nUPDATE LOG\n==========\n\nWordPress 5.9-beta4-52422\n-------------------------\n  Aggiornamento di WordPress 5.9-beta4-52422\n  Download dell\'aggiornamento da https://wordpress.org/nightly-builds/wordpress-latest.zip...\n  L\'autenticità di wordpress-latest.zip non può essere verificata.\n  Estrazione dell’aggiornamento in corso...\n  Verifica dei file estratti in corso...\n  Preparazione all’installazione dell\'ultima versione in corso...\n  Attivazione modalità di manutenzione in corso...\n  Copia dei file necessari in corso...\n  Disattivazione modalità di manutenzione in corso...\n  Aggiornamento del database in corso...\n  WordPress è stato aggiornato correttamente.\n', '', 'false', '2021-12-30 10:40:07', '', '127.0.0.1', 1, NULL),
(2, 'grgrzz008@gmail.com', '[Private Maket] Il tuo sito è aggiornato a WordPress 5.9-beta4-52422', 'Ciao! Il tuo sito su http://privatemarket.io è stato aggiornato automaticamente a WordPress 5.9-beta4-52422.\n\nNon è richiesta da parte tua alcuna altra operazione. Per altre informazioni sulla versione 5.9 vedi la schermata Informazioni su WordPress:\nhttp://privatemarket.io/wp-admin/about.php\n\nSe hai problemi di qualsiasi tipo o hai bisogno di aiuto, i volontari dei forum di supporto su https://it.wordpress.org/forums/ possono riuscire ad aiutarti.\nhttps://it.wordpress.org/support/forums/\n\nVi sono anche alcuni plugin o temi con aggiornamenti disponibili. Aggiornali ora:\nhttp://privatemarket.io/wp-admin/\n\nIl team di WordPress\n', '', 'false', '2021-12-30 10:40:07', '', '127.0.0.1', 1, NULL),
(3, 'grgrzz008@gmail.com', '[Private Maket] Aggiornamento in background completato', 'Sito WordPress: http://privatemarket.io/\nSUCCESSO: WordPress è stato correttamente aggiornato alla versione WordPress 5.9-beta4-52426\n\nLe seguenti traduzioni sono state aggiornate con successo:\n * SUCCESSO: Traduzioni per Twenty Twelve\n\nUPDATE LOG\n==========\n\nWordPress 5.9-beta4-52426\n-------------------------\n  Aggiornamento di WordPress 5.9-beta4-52426\n  Download dell\'aggiornamento da https://wordpress.org/nightly-builds/wordpress-latest.zip...\n  L\'autenticità di wordpress-latest.zip non può essere verificata.\n  Estrazione dell’aggiornamento in corso...\n  Verifica dei file estratti in corso...\n  Preparazione all’installazione dell\'ultima versione in corso...\n  Attivazione modalità di manutenzione in corso...\n  Copia dei file necessari in corso...\n  Disattivazione modalità di manutenzione in corso...\n  Aggiornamento del database in corso...\n  WordPress è stato aggiornato correttamente.\n\nTraduzioni per Twenty Twelve\n----------------------------\n  Aggiornamento delle traduzioni per Twenty Twelve (it_IT)...\n  Scaricamento della traduzione da https://downloads.wordpress.org/translation/theme/twentytwelve/3.5/it_IT.zip...\n  L\'autenticità di it_IT.zip non può essere verificata dato che non è stata trovata alcuna firma.\n  Estrazione dell’aggiornamento in corso...\n  Installazione dell’ultima versione in corso...\n  Rimozione della vecchia versione della traduzione...\n  Le traduzioni sono state aggiornate con successo.\n', '', 'false', '2022-01-01 11:14:21', '', '127.0.0.1', 1, NULL),
(4, 'grgrzz008@gmail.com', '[Private Maket] Il tuo sito è aggiornato a WordPress 5.9-beta4-52426', 'Ciao! Il tuo sito su http://privatemarket.io è stato aggiornato automaticamente a WordPress 5.9-beta4-52426.\n\nNon è richiesta da parte tua alcuna altra operazione. Per altre informazioni sulla versione 5.9 vedi la schermata Informazioni su WordPress:\nhttp://privatemarket.io/wp-admin/about.php\n\nSe hai problemi di qualsiasi tipo o hai bisogno di aiuto, i volontari dei forum di supporto su https://it.wordpress.org/forums/ possono riuscire ad aiutarti.\nhttps://it.wordpress.org/support/forums/\n\nVi sono anche alcuni plugin o temi con aggiornamenti disponibili. Aggiornali ora:\nhttp://privatemarket.io/wp-admin/\n\nIl team di WordPress\n', '', 'false', '2022-01-01 11:14:21', '', '127.0.0.1', 1, NULL),
(5, 'grgrzz008@gmail.com', '[Private Maket] Aggiornamento in background completato', 'Sito WordPress: http://privatemarket.io/\nLe seguenti traduzioni sono state aggiornate con successo:\n * SUCCESSO: Traduzioni per Contact Form 7\n\nUPDATE LOG\n==========\n\nTraduzioni per Contact Form 7\n-----------------------------\n  Aggiornamento delle traduzioni per Contact Form 7 (it_IT)...\n  Scaricamento della traduzione da https://downloads.wordpress.org/translation/plugin/contact-form-7/5.5.3/it_IT.zip...\n  L\'autenticità di it_IT.zip non può essere verificata dato che non è stata trovata alcuna firma.\n  Estrazione dell’aggiornamento in corso...\n  Installazione dell’ultima versione in corso...\n  Rimozione della vecchia versione della traduzione...\n  Le traduzioni sono state aggiornate con successo.\n', '', 'false', '2022-01-01 22:42:48', '', '127.0.0.1', 1, NULL) ;

#
# End of data contents of table `wp_email_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=771 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://privatemarket.io', 'yes'),
(2, 'home', 'http://privatemarket.io', 'yes'),
(3, 'blogname', 'Private Maket', 'yes'),
(4, 'blogdescription', 'Un nuovo sito targato WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'grgrzz008@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G:i', 'yes'),
(25, 'links_updated_date_format', 'j F Y G:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:49:"clear-cache-for-timber/clear-cache-for-timber.php";i:2;s:37:"custom-post-type-maker/class-cptm.php";i:3;s:59:"custom-post-type-permalinks/custom-post-type-permalinks.php";i:4;s:43:"post-meta-inspector/post-meta-inspector.php";i:5;s:25:"timber-library/timber.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'a5tratto-theme', 'yes'),
(41, 'stylesheet', 'a5tratto-theme-child', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:2:{s:59:"custom-post-type-permalinks/custom-post-type-permalinks.php";a:2:{i:0;s:4:"CPTP";i:1;s:9:"uninstall";}s:27:"wp-optimize/wp-optimize.php";s:21:"wpo_uninstall_actions";}', 'no'),
(80, 'timezone_string', 'Europe/Rome', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1656106657', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:17:"manage_email_logs";b:1;s:10:"copy_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:10:"copy_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'WPLANG', 'it_IT', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:158:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Articoli recenti</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:228:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Commenti recenti</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:145:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archivi</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:149:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categorie</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:9:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar_primary";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:10:"pre_footer";a:0:{}s:12:"footer_col_1";a:0:{}s:12:"footer_col_2";a:0:{}s:12:"footer_col_3";a:0:{}s:12:"footer_col_4";a:0:{}s:13:"footer_bottom";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:15:{i:1641123457;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1641123786;a:1:{s:21:"wpo_weekly_cron_tasks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1641136489;a:1:{s:32:"clear_cache_for_timber_cron_task";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641136540;a:1:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641136546;a:1:{s:37:"siteground_optimizer_check_assets_dir";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641136578;a:2:{s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:20:"cmplz_every_day_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"cmplz_daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641159457;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1641159573;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641159574;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641206587;a:1:{s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1641245857;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1641395741;a:1:{s:16:"wpseo_ryte_fetch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1641395778;a:1:{s:21:"cmplz_every_week_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:12:"cmplz_weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1643382978;a:1:{s:22:"cmplz_every_month_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:13:"cmplz_monthly";s:4:"args";a:0:{}s:8:"interval";i:2592000;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:24:"Richiesta HTTPS fallita.";}}', 'yes'),
(124, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1640555297;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(148, 'can_compress_scripts', '1', 'no'),
(157, 'finished_updating_comment_type', '1', 'yes'),
(158, 'current_theme', 'A5TRATTO Theme Child', 'yes'),
(159, 'theme_mods_privatemarket/resources', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1640790865;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:14:"sidebar-footer";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(160, 'theme_switched', '', 'yes'),
(161, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(163, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(166, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(200, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:19:"grgrzz008@gmail.com";s:7:"version";s:15:"5.9-beta4-52426";s:9:"timestamp";i:1641032061;}', 'no'),
(241, 'theme_mods_a5tratto-theme-child', 'a:12:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}s:18:"custom_css_post_id";i:-1;s:21:"a5t_setting_bootstrap";b:1;s:14:"a5t_setting_fa";b:1;s:19:"a5t_setting_animate";b:1;s:17:"a5t_setting_hover";b:1;s:24:"a5t_setting_owl_carousel";b:1;s:20:"a5t_setting_jarallax";b:1;s:21:"a5t_setting_nprogress";b:1;s:19:"a5t_setting_gototop";b:1;s:12:"a5t_adv_twig";b:1;}', 'yes'),
(243, 'a5t_theme_activation_options', 'a:5:{s:17:"create_front_page";b:0;s:22:"create_additional_page";b:0;s:26:"change_permalink_structure";b:0;s:23:"create_navigation_menus";b:0;s:31:"add_pages_to_primary_navigation";b:0;}', 'yes'),
(246, 'cmplz_show_terms_conditions_notice', '1640790894', 'yes'),
(247, 'cmplz_tour_started', '', 'no'),
(249, 'cptp_version', '3.4.5', 'yes'),
(250, 'queue_flush_rules', '0', 'yes'),
(253, 'email-log-db', '0.3', 'yes'),
(260, 'responsive_lightbox_lite_version', '1.3.3', 'yes'),
(261, 'responsive_lightbox_lite_settings', 'a:10:{s:6:"script";s:13:"nivo_lightbox";s:8:"selector";s:8:"lightbox";s:9:"galleries";b:1;s:6:"videos";b:1;s:11:"image_links";b:1;s:17:"images_as_gallery";b:0;s:19:"deactivation_delete";b:0;s:13:"loading_place";s:6:"header";s:20:"enable_custom_events";b:0;s:13:"custom_events";s:12:"ajaxComplete";}', 'no'),
(262, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"17.8";}', 'yes'),
(263, 'wpseo', 'a:54:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:26:"permalink_settings_changed";s:29:"indexables_indexing_completed";b:1;s:7:"version";s:4:"17.8";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:1;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1640790941;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:12:"/%postname%/";s:8:"home_url";s:23:"http://privatemarket.io";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:36:"dismiss_configuration_workout_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:18:"first_time_install";b:1;}', 'yes'),
(264, 'wpseo_titles', 'a:106:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'yes'),
(265, 'wpseo_social', 'a:18:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";}', 'yes'),
(266, 'siteground_optimizer_heartbeat_post_interval', '120', 'yes'),
(267, 'siteground_optimizer_excluded_lazy_load_media_types', 'a:9:{i:0;s:15:"lazyload_mobile";i:1;s:16:"lazyload_iframes";i:2;s:15:"lazyload_videos";i:3;s:18:"lazyload_gravatars";i:4;s:19:"lazyload_thumbnails";i:5;s:19:"lazyload_responsive";i:6;s:20:"lazyload_textwidgets";i:7;s:19:"lazyload_shortcodes";i:8;s:20:"lazyload_woocommerce";}', 'yes'),
(268, 'siteground_optimizer_version', '6.0.0', 'yes'),
(271, 'cmplz_activation_time', '1640790978', 'yes'),
(272, 'cmplz_cbdb_version', '5.5.3', 'yes'),
(273, 'jetpack_connection_active_plugins', 'a:1:{s:7:"jetpack";a:1:{s:4:"name";s:7:"Jetpack";}}', 'yes'),
(274, 'no_taxonomy_structure', '1', 'yes'),
(275, 'add_post_type_for_tax', '', 'yes'),
(277, 'acf_version', '5.8.7', 'yes'),
(281, 'duplicate_post_copytitle', '1', 'yes'),
(282, 'duplicate_post_copydate', '0', 'yes'),
(283, 'duplicate_post_copystatus', '0', 'yes'),
(284, 'duplicate_post_copyslug', '0', 'yes'),
(285, 'duplicate_post_copyexcerpt', '1', 'yes'),
(286, 'duplicate_post_copycontent', '1', 'yes'),
(287, 'duplicate_post_copythumbnail', '1', 'yes'),
(288, 'duplicate_post_copytemplate', '1', 'yes'),
(289, 'duplicate_post_copyformat', '1', 'yes'),
(290, 'duplicate_post_copyauthor', '0', 'yes'),
(291, 'duplicate_post_copypassword', '0', 'yes'),
(292, 'duplicate_post_copyattachments', '0', 'yes'),
(293, 'duplicate_post_copychildren', '0', 'yes'),
(294, 'duplicate_post_copycomments', '0', 'yes'),
(295, 'duplicate_post_copymenuorder', '1', 'yes'),
(296, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(297, 'duplicate_post_blacklist', '', 'yes'),
(298, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:"post";i:1;s:4:"page";}', 'yes'),
(299, 'duplicate_post_show_original_column', '0', 'yes'),
(300, 'duplicate_post_show_original_in_post_states', '0', 'yes'),
(301, 'duplicate_post_show_original_meta_box', '0', 'yes'),
(302, 'duplicate_post_show_link', 'a:3:{s:9:"new_draft";s:1:"1";s:5:"clone";s:1:"1";s:17:"rewrite_republish";s:1:"1";}', 'yes'),
(303, 'duplicate_post_show_link_in', 'a:4:{s:3:"row";s:1:"1";s:8:"adminbar";s:1:"1";s:9:"submitbox";s:1:"1";s:11:"bulkactions";s:1:"1";}', 'yes'),
(304, 'duplicate_post_show_notice', '0', 'no'),
(305, 'duplicate_post_version', '4.3', 'yes'),
(306, 'do_activate', '0', 'yes'),
(311, 'cmplz_cookietable_version', '5.5.3', 'yes'),
(312, 'cmplz_first_version', '5.5.3', 'yes'),
(313, 'cmplz-current-version', '5.5.3', 'yes'),
(332, 'cmplz_synced_cookiedatabase_once', '1', 'yes'),
(333, 'cmplz_last_cookie_scan', '1640799481', 'yes'),
(334, 'complianz_scan_token', '1640795881', 'yes'),
(337, 'cmplz_detected_social_media', 'a:0:{}', 'yes'),
(338, 'cmplz_detected_thirdparty_services', 'a:1:{i:0;s:12:"google-fonts";}', 'yes'),
(339, 'cmplz_detected_stats', 'a:0:{}', 'yes'),
(358, 'updraft_task_manager_dbversion', '1.1', 'yes'),
(361, 'wpseo_ryte', 'a:2:{s:6:"status";i:0;s:10:"last_fetch";i:1640791084;}', 'yes'),
(410, 'cmplz_excluded_posts_array', 'a:0:{}', 'yes'),
(411, 'tinypng_compression_timing', 'background', 'yes'),
(684, 'rewrite_rules', 'a:94:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(695, 'recently_activated', 'a:10:{s:36:"contact-form-7/wp-contact-form-7.php";i:1641120216;s:33:"complianz-gdpr/complianz-gpdr.php";i:1641120161;s:23:"email-log/email-log.php";i:1641120161;s:19:"jetpack/jetpack.php";i:1641120161;s:53:"responsive-lightbox-lite/responsive-lightbox-lite.php";i:1641120161;s:45:"tiny-compress-images/tiny-compress-images.php";i:1641120128;s:43:"wp-maintenance-mode/wp-maintenance-mode.php";i:1641120128;s:27:"wp-optimize/wp-optimize.php";i:1641120128;s:33:"duplicate-post/duplicate-post.php";i:1641120128;s:24:"wordpress-seo/wp-seo.php";i:1641120128;}', 'yes'),
(698, 'cmplz_tour_shown_once', '1', 'no'),
(766, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1641122130;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'template-home-child.php'),
(2, 3, '_wp_page_template', 'default'),
(19, 5, '_wp_trash_meta_status', 'publish'),
(20, 5, '_wp_trash_meta_time', '1640556143'),
(21, 2, '_edit_last', '1'),
(22, 2, '_edit_lock', '1641050271:1'),
(23, 9, '_wp_page_template', 'template-page.php'),
(24, 10, '_wp_page_template', 'archive.php'),
(25, 11, '_wp_page_template', 'template-page.php'),
(26, 12, '_wp_page_template', 'template-policy.php'),
(27, 13, '_wp_page_template', 'template-policy.php'),
(28, 14, '_wp_page_template', 'search.php'),
(91, 1, '_cmplz_scanned_post', '1'),
(92, 9, '_cmplz_scanned_post', '1'),
(93, 10, '_cmplz_scanned_post', '1'),
(94, 11, '_cmplz_scanned_post', '1'),
(95, 12, '_cmplz_scanned_post', '1'),
(96, 13, '_cmplz_scanned_post', '1'),
(97, 23, '_wp_trash_meta_status', 'publish'),
(98, 23, '_wp_trash_meta_time', '1640791129'),
(99, 24, '_wp_trash_meta_status', 'publish'),
(100, 24, '_wp_trash_meta_time', '1640791141'),
(101, 25, '_wp_trash_meta_status', 'publish'),
(102, 25, '_wp_trash_meta_time', '1640791172'),
(103, 26, '_edit_last', '1'),
(104, 26, '_edit_lock', '1641049453:1'),
(105, 2, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(106, 2, '_header_title', 'field_61cc8efbe62a1'),
(107, 2, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(108, 2, '_headet_button', 'field_61cc8f0ce62a2'),
(109, 2, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(110, 2, '_plus_description', 'field_61cc8f28e62a4'),
(111, 2, 'featured_title', 'Featured in'),
(112, 2, '_featured_title', 'field_61cc8f46e62a6'),
(113, 2, 'featureds', '5'),
(114, 2, '_featureds', 'field_61cc8f51e62a7'),
(115, 2, 'investors_title', 'For Investors and Advisors'),
(116, 2, '_investors_title', 'field_61cc8fe8e62aa'),
(117, 2, 'investors', '3'),
(118, 2, '_investors', 'field_61cc8feee62ab'),
(119, 2, 'founds_title', 'For Fund Managers'),
(120, 2, '_founds_title', 'field_61cc9064e62b0'),
(121, 2, 'founds', '3'),
(122, 2, '_founds', 'field_61cc9078e62b1'),
(123, 2, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(124, 2, '_tech_title', 'field_61cc90cbe62b3'),
(125, 2, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(126, 2, '_tech_description', 'field_61cc912b162cb'),
(127, 2, 'Techs', '4'),
(128, 2, '_Techs', 'field_61cc90dbe62b4'),
(129, 2, 'partner_title', 'Our Trusted Partners'),
(130, 2, '_partner_title', 'field_61cc9177162cf'),
(131, 2, 'partners', '5'),
(132, 2, '_partners', 'field_61cc918e162d0'),
(133, 2, 'contact_title', 'Contact us to learn more about our services'),
(134, 2, '_contact_title', 'field_61cc91cd8d63b'),
(135, 2, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(136, 2, '_contact_button', 'field_61cc91d68d63c'),
(137, 8, 'header_title', ''),
(138, 8, '_header_title', 'field_61cc8efbe62a1'),
(139, 8, 'headet_button', ''),
(140, 8, '_headet_button', 'field_61cc8f0ce62a2'),
(141, 8, 'plus_description', ''),
(142, 8, '_plus_description', 'field_61cc8f28e62a4'),
(143, 8, 'featured_title', ''),
(144, 8, '_featured_title', 'field_61cc8f46e62a6'),
(145, 8, 'featureds', ''),
(146, 8, '_featureds', 'field_61cc8f51e62a7'),
(147, 8, 'investors_title', ''),
(148, 8, '_investors_title', 'field_61cc8fe8e62aa'),
(149, 8, 'investors', ''),
(150, 8, '_investors', 'field_61cc8feee62ab'),
(151, 8, 'founds_title', ''),
(152, 8, '_founds_title', 'field_61cc9064e62b0'),
(153, 8, 'founds', ''),
(154, 8, '_founds', 'field_61cc9078e62b1'),
(155, 8, 'tech_title', ''),
(156, 8, '_tech_title', 'field_61cc90cbe62b3'),
(157, 8, 'tech_description', ''),
(158, 8, '_tech_description', 'field_61cc912b162cb'),
(159, 8, 'Techs', ''),
(160, 8, '_Techs', 'field_61cc90dbe62b4'),
(161, 8, 'partner_title', ''),
(162, 8, '_partner_title', 'field_61cc9177162cf'),
(163, 8, 'partners', ''),
(164, 8, '_partners', 'field_61cc918e162d0'),
(165, 8, 'contact_title', ''),
(166, 8, '_contact_title', 'field_61cc91cd8d63b'),
(167, 8, 'contact_button', ''),
(168, 8, '_contact_button', 'field_61cc91d68d63c'),
(169, 2, 'cmplz_hide_cookiebanner', ''),
(170, 2, '_yoast_wpseo_content_score', '90'),
(171, 2, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(172, 59, '_wp_attached_file', '2021/12/avcj.png'),
(173, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"51";s:4:"file";s:16:"2021/12/avcj.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:14:"avcj-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(174, 59, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798655;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798655;}}'),
(175, 60, '_wp_attached_file', '2021/12/bitcoinmagazine.png'),
(176, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"260";s:6:"height";s:2:"30";s:4:"file";s:27:"2021/12/bitcoinmagazine.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"bitcoinmagazine-150x30.png";s:5:"width";s:3:"150";s:6:"height";s:2:"30";s:9:"mime-type";s:9:"image/png";}s:9:"cptm_icon";a:4:{s:4:"file";s:25:"bitcoinmagazine-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(177, 60, 'tiny_compress_images', 'a:3:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798657;}s:9:"thumbnail";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798657;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798657;}}'),
(178, 61, '_wp_attached_file', '2021/12/businesswire.png') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(179, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"160";s:6:"height";s:2:"67";s:4:"file";s:24:"2021/12/businesswire.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"businesswire-150x67.png";s:5:"width";s:3:"150";s:6:"height";s:2:"67";s:9:"mime-type";s:9:"image/png";}s:9:"cptm_icon";a:4:{s:4:"file";s:22:"businesswire-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(180, 61, 'tiny_compress_images', 'a:3:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798658;}s:9:"thumbnail";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798658;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798658;}}'),
(181, 62, '_wp_attached_file', '2021/12/cnn.png'),
(182, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"35";s:4:"file";s:15:"2021/12/cnn.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:13:"cnn-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(183, 62, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798660;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798660;}}'),
(184, 63, '_wp_attached_file', '2021/12/finextra.png'),
(185, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"31";s:4:"file";s:20:"2021/12/finextra.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:18:"finextra-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(186, 63, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798662;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640798662;}}'),
(187, 2, 'featureds_0_img', '59'),
(188, 2, '_featureds_0_img', 'field_61cc8f61e62a8'),
(189, 2, 'featureds_1_img', '60'),
(190, 2, '_featureds_1_img', 'field_61cc8f61e62a8'),
(191, 2, 'featureds_2_img', '61'),
(192, 2, '_featureds_2_img', 'field_61cc8f61e62a8'),
(193, 2, 'featureds_3_img', '62'),
(194, 2, '_featureds_3_img', 'field_61cc8f61e62a8'),
(195, 2, 'featureds_4_img', '63'),
(196, 2, '_featureds_4_img', 'field_61cc8f61e62a8'),
(197, 64, 'header_title', ''),
(198, 64, '_header_title', 'field_61cc8efbe62a1'),
(199, 64, 'headet_button', ''),
(200, 64, '_headet_button', 'field_61cc8f0ce62a2'),
(201, 64, 'plus_description', ''),
(202, 64, '_plus_description', 'field_61cc8f28e62a4'),
(203, 64, 'featured_title', ''),
(204, 64, '_featured_title', 'field_61cc8f46e62a6'),
(205, 64, 'featureds', '5'),
(206, 64, '_featureds', 'field_61cc8f51e62a7'),
(207, 64, 'investors_title', ''),
(208, 64, '_investors_title', 'field_61cc8fe8e62aa'),
(209, 64, 'investors', ''),
(210, 64, '_investors', 'field_61cc8feee62ab'),
(211, 64, 'founds_title', ''),
(212, 64, '_founds_title', 'field_61cc9064e62b0'),
(213, 64, 'founds', ''),
(214, 64, '_founds', 'field_61cc9078e62b1'),
(215, 64, 'tech_title', ''),
(216, 64, '_tech_title', 'field_61cc90cbe62b3'),
(217, 64, 'tech_description', ''),
(218, 64, '_tech_description', 'field_61cc912b162cb'),
(219, 64, 'Techs', ''),
(220, 64, '_Techs', 'field_61cc90dbe62b4'),
(221, 64, 'partner_title', ''),
(222, 64, '_partner_title', 'field_61cc9177162cf'),
(223, 64, 'partners', ''),
(224, 64, '_partners', 'field_61cc918e162d0'),
(225, 64, 'contact_title', ''),
(226, 64, '_contact_title', 'field_61cc91cd8d63b'),
(227, 64, 'contact_button', ''),
(228, 64, '_contact_button', 'field_61cc91d68d63c'),
(229, 64, 'featureds_0_img', '59'),
(230, 64, '_featureds_0_img', 'field_61cc8f61e62a8'),
(231, 64, 'featureds_1_img', '60'),
(232, 64, '_featureds_1_img', 'field_61cc8f61e62a8'),
(233, 64, 'featureds_2_img', '61'),
(234, 64, '_featureds_2_img', 'field_61cc8f61e62a8'),
(235, 64, 'featureds_3_img', '62'),
(236, 64, '_featureds_3_img', 'field_61cc8f61e62a8'),
(237, 64, 'featureds_4_img', '63'),
(238, 64, '_featureds_4_img', 'field_61cc8f61e62a8'),
(239, 2, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(240, 2, '_investors_0_description', 'field_61cc901ae62ac'),
(241, 2, 'investors_1_description', 'On-demand professional investment services'),
(242, 2, '_investors_1_description', 'field_61cc901ae62ac'),
(243, 2, 'investors_2_description', 'Unique liquidity management solutions'),
(244, 2, '_investors_2_description', 'field_61cc901ae62ac'),
(245, 65, 'header_title', ''),
(246, 65, '_header_title', 'field_61cc8efbe62a1'),
(247, 65, 'headet_button', ''),
(248, 65, '_headet_button', 'field_61cc8f0ce62a2'),
(249, 65, 'plus_description', ''),
(250, 65, '_plus_description', 'field_61cc8f28e62a4'),
(251, 65, 'featured_title', ''),
(252, 65, '_featured_title', 'field_61cc8f46e62a6'),
(253, 65, 'featureds', '5'),
(254, 65, '_featureds', 'field_61cc8f51e62a7'),
(255, 65, 'investors_title', 'For Investors  and Advisors'),
(256, 65, '_investors_title', 'field_61cc8fe8e62aa'),
(257, 65, 'investors', '3'),
(258, 65, '_investors', 'field_61cc8feee62ab'),
(259, 65, 'founds_title', ''),
(260, 65, '_founds_title', 'field_61cc9064e62b0'),
(261, 65, 'founds', ''),
(262, 65, '_founds', 'field_61cc9078e62b1'),
(263, 65, 'tech_title', ''),
(264, 65, '_tech_title', 'field_61cc90cbe62b3'),
(265, 65, 'tech_description', ''),
(266, 65, '_tech_description', 'field_61cc912b162cb'),
(267, 65, 'Techs', ''),
(268, 65, '_Techs', 'field_61cc90dbe62b4'),
(269, 65, 'partner_title', ''),
(270, 65, '_partner_title', 'field_61cc9177162cf'),
(271, 65, 'partners', ''),
(272, 65, '_partners', 'field_61cc918e162d0'),
(273, 65, 'contact_title', ''),
(274, 65, '_contact_title', 'field_61cc91cd8d63b'),
(275, 65, 'contact_button', ''),
(276, 65, '_contact_button', 'field_61cc91d68d63c'),
(277, 65, 'featureds_0_img', '59'),
(278, 65, '_featureds_0_img', 'field_61cc8f61e62a8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(279, 65, 'featureds_1_img', '60'),
(280, 65, '_featureds_1_img', 'field_61cc8f61e62a8'),
(281, 65, 'featureds_2_img', '61'),
(282, 65, '_featureds_2_img', 'field_61cc8f61e62a8'),
(283, 65, 'featureds_3_img', '62'),
(284, 65, '_featureds_3_img', 'field_61cc8f61e62a8'),
(285, 65, 'featureds_4_img', '63'),
(286, 65, '_featureds_4_img', 'field_61cc8f61e62a8'),
(287, 65, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(288, 65, '_investors_0_description', 'field_61cc901ae62ac'),
(289, 65, 'investors_1_description', 'On-demand professional investment services'),
(290, 65, '_investors_1_description', 'field_61cc901ae62ac'),
(291, 65, 'investors_2_description', 'Unique liquidity management solutions'),
(292, 65, '_investors_2_description', 'field_61cc901ae62ac'),
(293, 66, '_wp_attached_file', '2021/12/avcj-1.png'),
(294, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"51";s:4:"file";s:18:"2021/12/avcj-1.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:16:"avcj-1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(295, 66, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819865;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819865;}}'),
(296, 67, '_wp_attached_file', '2021/12/bitcoinmagazine-1.png'),
(297, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"260";s:6:"height";s:2:"30";s:4:"file";s:29:"2021/12/bitcoinmagazine-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"bitcoinmagazine-1-150x30.png";s:5:"width";s:3:"150";s:6:"height";s:2:"30";s:9:"mime-type";s:9:"image/png";}s:9:"cptm_icon";a:4:{s:4:"file";s:27:"bitcoinmagazine-1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(298, 67, 'tiny_compress_images', 'a:3:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819867;}s:9:"thumbnail";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819867;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819867;}}'),
(299, 68, '_wp_attached_file', '2021/12/businesswire-1.png'),
(300, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"160";s:6:"height";s:2:"67";s:4:"file";s:26:"2021/12/businesswire-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"businesswire-1-150x67.png";s:5:"width";s:3:"150";s:6:"height";s:2:"67";s:9:"mime-type";s:9:"image/png";}s:9:"cptm_icon";a:4:{s:4:"file";s:24:"businesswire-1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(301, 68, 'tiny_compress_images', 'a:3:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819868;}s:9:"thumbnail";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819868;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819868;}}'),
(302, 69, '_wp_attached_file', '2021/12/cnn-1.png'),
(303, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"35";s:4:"file";s:17:"2021/12/cnn-1.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:15:"cnn-1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(304, 69, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819870;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819870;}}'),
(305, 70, '_wp_attached_file', '2021/12/finextra-1.png'),
(306, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:3:"140";s:6:"height";s:2:"31";s:4:"file";s:22:"2021/12/finextra-1.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:20:"finextra-1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(307, 70, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819872;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819872;}}'),
(308, 71, '_wp_attached_file', '2021/12/box1.png'),
(309, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:2:"49";s:6:"height";s:2:"40";s:4:"file";s:16:"2021/12/box1.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:14:"box1-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(310, 71, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819991;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819991;}}'),
(311, 72, '_wp_attached_file', '2021/12/box2.png'),
(312, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:2:"50";s:6:"height";s:2:"39";s:4:"file";s:16:"2021/12/box2.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:14:"box2-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(313, 72, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819997;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640819997;}}'),
(314, 73, '_wp_attached_file', '2021/12/box3.png'),
(315, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:2:"50";s:6:"height";s:2:"58";s:4:"file";s:16:"2021/12/box3.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:14:"box3-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(316, 73, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640820005;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640820005;}}'),
(317, 74, '_wp_attached_file', '2021/12/box4.png'),
(318, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";s:2:"50";s:6:"height";s:2:"58";s:4:"file";s:16:"2021/12/box4.png";s:5:"sizes";a:1:{s:9:"cptm_icon";a:4:{s:4:"file";s:14:"box4-16x16.png";s:5:"width";s:2:"16";s:6:"height";s:2:"16";s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(319, 74, 'tiny_compress_images', 'a:2:{i:0;a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640820013;}s:9:"cptm_icon";a:3:{s:5:"error";s:8:"KeyError";s:7:"message";s:47:"Register an account or provide an API key first";s:9:"timestamp";i:1640820013;}}'),
(320, 2, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(321, 2, '_founds_0_description', 'field_61cc9103e62b6'),
(322, 2, 'founds_1_description', 'Single point of contact for qualified investors'),
(323, 2, '_founds_1_description', 'field_61cc9103e62b6'),
(324, 2, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(325, 2, '_founds_2_description', 'field_61cc9103e62b6'),
(326, 2, 'Techs_0_description_copia', 'Asset Liquidity'),
(327, 2, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(328, 2, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(329, 2, '_Techs_0_description', 'field_61cc90eee62b5'),
(330, 2, 'Techs_0_img', '71'),
(331, 2, '_Techs_0_img', 'field_61cc9146162cd'),
(332, 2, 'Techs_1_description_copia', 'Immutable Ledger'),
(333, 2, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(334, 2, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(335, 2, '_Techs_1_description', 'field_61cc90eee62b5'),
(336, 2, 'Techs_1_img', '72'),
(337, 2, '_Techs_1_img', 'field_61cc9146162cd'),
(338, 2, 'Techs_2_description_copia', 'Transparent Ownership'),
(339, 2, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(340, 2, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(341, 2, '_Techs_2_description', 'field_61cc90eee62b5'),
(342, 2, 'Techs_2_img', '73'),
(343, 2, '_Techs_2_img', 'field_61cc9146162cd'),
(344, 2, 'Techs_3_description_copia', 'Digital ID'),
(345, 2, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(346, 2, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(347, 2, '_Techs_3_description', 'field_61cc90eee62b5'),
(348, 2, 'Techs_3_img', '74'),
(349, 2, '_Techs_3_img', 'field_61cc9146162cd'),
(350, 2, 'partners_0_img', '66'),
(351, 2, '_partners_0_img', 'field_61cc919b162d1'),
(352, 2, 'partners_1_img', '67'),
(353, 2, '_partners_1_img', 'field_61cc919b162d1'),
(354, 2, 'partners_2_img', '68'),
(355, 2, '_partners_2_img', 'field_61cc919b162d1'),
(356, 2, 'partners_3_img', '69'),
(357, 2, '_partners_3_img', 'field_61cc919b162d1'),
(358, 2, 'partners_4_img', '70'),
(359, 2, '_partners_4_img', 'field_61cc919b162d1'),
(360, 75, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(361, 75, '_header_title', 'field_61cc8efbe62a1'),
(362, 75, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(363, 75, '_headet_button', 'field_61cc8f0ce62a2'),
(364, 75, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(365, 75, '_plus_description', 'field_61cc8f28e62a4'),
(366, 75, 'featured_title', 'Featured in'),
(367, 75, '_featured_title', 'field_61cc8f46e62a6'),
(368, 75, 'featureds', '5'),
(369, 75, '_featureds', 'field_61cc8f51e62a7'),
(370, 75, 'investors_title', 'For Investors  and Advisors'),
(371, 75, '_investors_title', 'field_61cc8fe8e62aa'),
(372, 75, 'investors', '3'),
(373, 75, '_investors', 'field_61cc8feee62ab'),
(374, 75, 'founds_title', 'For Fund  Managers'),
(375, 75, '_founds_title', 'field_61cc9064e62b0'),
(376, 75, 'founds', '3'),
(377, 75, '_founds', 'field_61cc9078e62b1'),
(378, 75, 'tech_title', 'Tokenized investment products using proprietary blockchain technology') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(379, 75, '_tech_title', 'field_61cc90cbe62b3'),
(380, 75, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(381, 75, '_tech_description', 'field_61cc912b162cb'),
(382, 75, 'Techs', '4'),
(383, 75, '_Techs', 'field_61cc90dbe62b4'),
(384, 75, 'partner_title', 'Our Trusted Partners'),
(385, 75, '_partner_title', 'field_61cc9177162cf'),
(386, 75, 'partners', '5'),
(387, 75, '_partners', 'field_61cc918e162d0'),
(388, 75, 'contact_title', 'Contact us to learn more about our services'),
(389, 75, '_contact_title', 'field_61cc91cd8d63b'),
(390, 75, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(391, 75, '_contact_button', 'field_61cc91d68d63c'),
(392, 75, 'featureds_0_img', '59'),
(393, 75, '_featureds_0_img', 'field_61cc8f61e62a8'),
(394, 75, 'featureds_1_img', '60'),
(395, 75, '_featureds_1_img', 'field_61cc8f61e62a8'),
(396, 75, 'featureds_2_img', '61'),
(397, 75, '_featureds_2_img', 'field_61cc8f61e62a8'),
(398, 75, 'featureds_3_img', '62'),
(399, 75, '_featureds_3_img', 'field_61cc8f61e62a8'),
(400, 75, 'featureds_4_img', '63'),
(401, 75, '_featureds_4_img', 'field_61cc8f61e62a8'),
(402, 75, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(403, 75, '_investors_0_description', 'field_61cc901ae62ac'),
(404, 75, 'investors_1_description', 'On-demand professional investment services'),
(405, 75, '_investors_1_description', 'field_61cc901ae62ac'),
(406, 75, 'investors_2_description', 'Unique liquidity management solutions'),
(407, 75, '_investors_2_description', 'field_61cc901ae62ac'),
(408, 75, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(409, 75, '_founds_0_description', 'field_61cc9103e62b6'),
(410, 75, 'founds_1_description', 'Single point of contact for qualified investors'),
(411, 75, '_founds_1_description', 'field_61cc9103e62b6'),
(412, 75, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(413, 75, '_founds_2_description', 'field_61cc9103e62b6'),
(414, 75, 'Techs_0_description_copia', 'Asset Liquidity'),
(415, 75, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(416, 75, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(417, 75, '_Techs_0_description', 'field_61cc90eee62b5'),
(418, 75, 'Techs_0_img', '71'),
(419, 75, '_Techs_0_img', 'field_61cc9146162cd'),
(420, 75, 'Techs_1_description_copia', 'Immutable Ledger'),
(421, 75, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(422, 75, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(423, 75, '_Techs_1_description', 'field_61cc90eee62b5'),
(424, 75, 'Techs_1_img', '72'),
(425, 75, '_Techs_1_img', 'field_61cc9146162cd'),
(426, 75, 'Techs_2_description_copia', 'Transparent Ownership'),
(427, 75, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(428, 75, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(429, 75, '_Techs_2_description', 'field_61cc90eee62b5'),
(430, 75, 'Techs_2_img', '73'),
(431, 75, '_Techs_2_img', 'field_61cc9146162cd'),
(432, 75, 'Techs_3_description_copia', 'Digital ID'),
(433, 75, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(434, 75, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(435, 75, '_Techs_3_description', 'field_61cc90eee62b5'),
(436, 75, 'Techs_3_img', '74'),
(437, 75, '_Techs_3_img', 'field_61cc9146162cd'),
(438, 75, 'partners_0_img', '66'),
(439, 75, '_partners_0_img', 'field_61cc919b162d1'),
(440, 75, 'partners_1_img', '67'),
(441, 75, '_partners_1_img', 'field_61cc919b162d1'),
(442, 75, 'partners_2_img', '68'),
(443, 75, '_partners_2_img', 'field_61cc919b162d1'),
(444, 75, 'partners_3_img', '69'),
(445, 75, '_partners_3_img', 'field_61cc919b162d1'),
(446, 75, 'partners_4_img', '70'),
(447, 75, '_partners_4_img', 'field_61cc919b162d1'),
(448, 2, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(449, 2, '_header_button', 'field_61cc8f0ce62a2'),
(450, 76, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(451, 76, '_header_title', 'field_61cc8efbe62a1'),
(452, 76, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(453, 76, '_headet_button', 'field_61cc8f0ce62a2'),
(454, 76, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(455, 76, '_plus_description', 'field_61cc8f28e62a4'),
(456, 76, 'featured_title', 'Featured in'),
(457, 76, '_featured_title', 'field_61cc8f46e62a6'),
(458, 76, 'featureds', '5'),
(459, 76, '_featureds', 'field_61cc8f51e62a7'),
(460, 76, 'investors_title', 'For Investors  and Advisors'),
(461, 76, '_investors_title', 'field_61cc8fe8e62aa'),
(462, 76, 'investors', '3'),
(463, 76, '_investors', 'field_61cc8feee62ab'),
(464, 76, 'founds_title', 'For Fund  Managers'),
(465, 76, '_founds_title', 'field_61cc9064e62b0'),
(466, 76, 'founds', '3'),
(467, 76, '_founds', 'field_61cc9078e62b1'),
(468, 76, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(469, 76, '_tech_title', 'field_61cc90cbe62b3'),
(470, 76, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(471, 76, '_tech_description', 'field_61cc912b162cb'),
(472, 76, 'Techs', '4'),
(473, 76, '_Techs', 'field_61cc90dbe62b4'),
(474, 76, 'partner_title', 'Our Trusted Partners'),
(475, 76, '_partner_title', 'field_61cc9177162cf'),
(476, 76, 'partners', '5'),
(477, 76, '_partners', 'field_61cc918e162d0'),
(478, 76, 'contact_title', 'Contact us to learn more about our services') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(479, 76, '_contact_title', 'field_61cc91cd8d63b'),
(480, 76, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(481, 76, '_contact_button', 'field_61cc91d68d63c'),
(482, 76, 'featureds_0_img', '59'),
(483, 76, '_featureds_0_img', 'field_61cc8f61e62a8'),
(484, 76, 'featureds_1_img', '60'),
(485, 76, '_featureds_1_img', 'field_61cc8f61e62a8'),
(486, 76, 'featureds_2_img', '61'),
(487, 76, '_featureds_2_img', 'field_61cc8f61e62a8'),
(488, 76, 'featureds_3_img', '62'),
(489, 76, '_featureds_3_img', 'field_61cc8f61e62a8'),
(490, 76, 'featureds_4_img', '63'),
(491, 76, '_featureds_4_img', 'field_61cc8f61e62a8'),
(492, 76, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(493, 76, '_investors_0_description', 'field_61cc901ae62ac'),
(494, 76, 'investors_1_description', 'On-demand professional investment services'),
(495, 76, '_investors_1_description', 'field_61cc901ae62ac'),
(496, 76, 'investors_2_description', 'Unique liquidity management solutions'),
(497, 76, '_investors_2_description', 'field_61cc901ae62ac'),
(498, 76, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(499, 76, '_founds_0_description', 'field_61cc9103e62b6'),
(500, 76, 'founds_1_description', 'Single point of contact for qualified investors'),
(501, 76, '_founds_1_description', 'field_61cc9103e62b6'),
(502, 76, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(503, 76, '_founds_2_description', 'field_61cc9103e62b6'),
(504, 76, 'Techs_0_description_copia', 'Asset Liquidity'),
(505, 76, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(506, 76, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(507, 76, '_Techs_0_description', 'field_61cc90eee62b5'),
(508, 76, 'Techs_0_img', '71'),
(509, 76, '_Techs_0_img', 'field_61cc9146162cd'),
(510, 76, 'Techs_1_description_copia', 'Immutable Ledger'),
(511, 76, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(512, 76, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(513, 76, '_Techs_1_description', 'field_61cc90eee62b5'),
(514, 76, 'Techs_1_img', '72'),
(515, 76, '_Techs_1_img', 'field_61cc9146162cd'),
(516, 76, 'Techs_2_description_copia', 'Transparent Ownership'),
(517, 76, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(518, 76, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(519, 76, '_Techs_2_description', 'field_61cc90eee62b5'),
(520, 76, 'Techs_2_img', '73'),
(521, 76, '_Techs_2_img', 'field_61cc9146162cd'),
(522, 76, 'Techs_3_description_copia', 'Digital ID'),
(523, 76, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(524, 76, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(525, 76, '_Techs_3_description', 'field_61cc90eee62b5'),
(526, 76, 'Techs_3_img', '74'),
(527, 76, '_Techs_3_img', 'field_61cc9146162cd'),
(528, 76, 'partners_0_img', '66'),
(529, 76, '_partners_0_img', 'field_61cc919b162d1'),
(530, 76, 'partners_1_img', '67'),
(531, 76, '_partners_1_img', 'field_61cc919b162d1'),
(532, 76, 'partners_2_img', '68'),
(533, 76, '_partners_2_img', 'field_61cc919b162d1'),
(534, 76, 'partners_3_img', '69'),
(535, 76, '_partners_3_img', 'field_61cc919b162d1'),
(536, 76, 'partners_4_img', '70'),
(537, 76, '_partners_4_img', 'field_61cc919b162d1'),
(538, 76, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(539, 76, '_header_button', 'field_61cc8f0ce62a2'),
(540, 77, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(541, 77, '_header_title', 'field_61cc8efbe62a1'),
(542, 77, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(543, 77, '_headet_button', 'field_61cc8f0ce62a2'),
(544, 77, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(545, 77, '_plus_description', 'field_61cc8f28e62a4'),
(546, 77, 'featured_title', 'Featured in'),
(547, 77, '_featured_title', 'field_61cc8f46e62a6'),
(548, 77, 'featureds', '5'),
(549, 77, '_featureds', 'field_61cc8f51e62a7'),
(550, 77, 'investors_title', 'For Investors  and Advisors'),
(551, 77, '_investors_title', 'field_61cc8fe8e62aa'),
(552, 77, 'investors', '3'),
(553, 77, '_investors', 'field_61cc8feee62ab'),
(554, 77, 'founds_title', 'For Fund  Managers'),
(555, 77, '_founds_title', 'field_61cc9064e62b0'),
(556, 77, 'founds', '3'),
(557, 77, '_founds', 'field_61cc9078e62b1'),
(558, 77, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(559, 77, '_tech_title', 'field_61cc90cbe62b3'),
(560, 77, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(561, 77, '_tech_description', 'field_61cc912b162cb'),
(562, 77, 'Techs', '4'),
(563, 77, '_Techs', 'field_61cc90dbe62b4'),
(564, 77, 'partner_title', 'Our Trusted Partners'),
(565, 77, '_partner_title', 'field_61cc9177162cf'),
(566, 77, 'partners', '5'),
(567, 77, '_partners', 'field_61cc918e162d0'),
(568, 77, 'contact_title', 'Contact us to learn more about our services'),
(569, 77, '_contact_title', 'field_61cc91cd8d63b'),
(570, 77, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(571, 77, '_contact_button', 'field_61cc91d68d63c'),
(572, 77, 'featureds_0_img', '59'),
(573, 77, '_featureds_0_img', 'field_61cc8f61e62a8'),
(574, 77, 'featureds_1_img', '60'),
(575, 77, '_featureds_1_img', 'field_61cc8f61e62a8'),
(576, 77, 'featureds_2_img', '61'),
(577, 77, '_featureds_2_img', 'field_61cc8f61e62a8'),
(578, 77, 'featureds_3_img', '62') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(579, 77, '_featureds_3_img', 'field_61cc8f61e62a8'),
(580, 77, 'featureds_4_img', '63'),
(581, 77, '_featureds_4_img', 'field_61cc8f61e62a8'),
(582, 77, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(583, 77, '_investors_0_description', 'field_61cc901ae62ac'),
(584, 77, 'investors_1_description', 'On-demand professional investment services'),
(585, 77, '_investors_1_description', 'field_61cc901ae62ac'),
(586, 77, 'investors_2_description', 'Unique liquidity management solutions'),
(587, 77, '_investors_2_description', 'field_61cc901ae62ac'),
(588, 77, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(589, 77, '_founds_0_description', 'field_61cc9103e62b6'),
(590, 77, 'founds_1_description', 'Single point of contact for qualified investors'),
(591, 77, '_founds_1_description', 'field_61cc9103e62b6'),
(592, 77, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(593, 77, '_founds_2_description', 'field_61cc9103e62b6'),
(594, 77, 'Techs_0_description_copia', 'Asset Liquidity'),
(595, 77, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(596, 77, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(597, 77, '_Techs_0_description', 'field_61cc90eee62b5'),
(598, 77, 'Techs_0_img', '71'),
(599, 77, '_Techs_0_img', 'field_61cc9146162cd'),
(600, 77, 'Techs_1_description_copia', 'Immutable Ledger'),
(601, 77, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(602, 77, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(603, 77, '_Techs_1_description', 'field_61cc90eee62b5'),
(604, 77, 'Techs_1_img', '72'),
(605, 77, '_Techs_1_img', 'field_61cc9146162cd'),
(606, 77, 'Techs_2_description_copia', 'Transparent Ownership'),
(607, 77, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(608, 77, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(609, 77, '_Techs_2_description', 'field_61cc90eee62b5'),
(610, 77, 'Techs_2_img', '73'),
(611, 77, '_Techs_2_img', 'field_61cc9146162cd'),
(612, 77, 'Techs_3_description_copia', 'Digital ID'),
(613, 77, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(614, 77, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(615, 77, '_Techs_3_description', 'field_61cc90eee62b5'),
(616, 77, 'Techs_3_img', '74'),
(617, 77, '_Techs_3_img', 'field_61cc9146162cd'),
(618, 77, 'partners_0_img', '66'),
(619, 77, '_partners_0_img', 'field_61cc919b162d1'),
(620, 77, 'partners_1_img', '67'),
(621, 77, '_partners_1_img', 'field_61cc919b162d1'),
(622, 77, 'partners_2_img', '68'),
(623, 77, '_partners_2_img', 'field_61cc919b162d1'),
(624, 77, 'partners_3_img', '69'),
(625, 77, '_partners_3_img', 'field_61cc919b162d1'),
(626, 77, 'partners_4_img', '70'),
(627, 77, '_partners_4_img', 'field_61cc919b162d1'),
(628, 77, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(629, 77, '_header_button', 'field_61cc8f0ce62a2'),
(630, 78, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(631, 78, '_header_title', 'field_61cc8efbe62a1'),
(632, 78, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(633, 78, '_headet_button', 'field_61cc8f0ce62a2'),
(634, 78, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(635, 78, '_plus_description', 'field_61cc8f28e62a4'),
(636, 78, 'featured_title', 'Featured in'),
(637, 78, '_featured_title', 'field_61cc8f46e62a6'),
(638, 78, 'featureds', '5'),
(639, 78, '_featureds', 'field_61cc8f51e62a7'),
(640, 78, 'investors_title', 'For Investors  and Advisors'),
(641, 78, '_investors_title', 'field_61cc8fe8e62aa'),
(642, 78, 'investors', '3'),
(643, 78, '_investors', 'field_61cc8feee62ab'),
(644, 78, 'founds_title', 'For Fund  Managers'),
(645, 78, '_founds_title', 'field_61cc9064e62b0'),
(646, 78, 'founds', '3'),
(647, 78, '_founds', 'field_61cc9078e62b1'),
(648, 78, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(649, 78, '_tech_title', 'field_61cc90cbe62b3'),
(650, 78, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(651, 78, '_tech_description', 'field_61cc912b162cb'),
(652, 78, 'Techs', '4'),
(653, 78, '_Techs', 'field_61cc90dbe62b4'),
(654, 78, 'partner_title', 'Our Trusted Partners'),
(655, 78, '_partner_title', 'field_61cc9177162cf'),
(656, 78, 'partners', '5'),
(657, 78, '_partners', 'field_61cc918e162d0'),
(658, 78, 'contact_title', 'Contact us to learn more about our services'),
(659, 78, '_contact_title', 'field_61cc91cd8d63b'),
(660, 78, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(661, 78, '_contact_button', 'field_61cc91d68d63c'),
(662, 78, 'featureds_0_img', '59'),
(663, 78, '_featureds_0_img', 'field_61cc8f61e62a8'),
(664, 78, 'featureds_1_img', '60'),
(665, 78, '_featureds_1_img', 'field_61cc8f61e62a8'),
(666, 78, 'featureds_2_img', '61'),
(667, 78, '_featureds_2_img', 'field_61cc8f61e62a8'),
(668, 78, 'featureds_3_img', '62'),
(669, 78, '_featureds_3_img', 'field_61cc8f61e62a8'),
(670, 78, 'featureds_4_img', '63'),
(671, 78, '_featureds_4_img', 'field_61cc8f61e62a8'),
(672, 78, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(673, 78, '_investors_0_description', 'field_61cc901ae62ac'),
(674, 78, 'investors_1_description', 'On-demand professional investment services'),
(675, 78, '_investors_1_description', 'field_61cc901ae62ac'),
(676, 78, 'investors_2_description', 'Unique liquidity management solutions'),
(677, 78, '_investors_2_description', 'field_61cc901ae62ac'),
(678, 78, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(679, 78, '_founds_0_description', 'field_61cc9103e62b6'),
(680, 78, 'founds_1_description', 'Single point of contact for qualified investors'),
(681, 78, '_founds_1_description', 'field_61cc9103e62b6'),
(682, 78, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(683, 78, '_founds_2_description', 'field_61cc9103e62b6'),
(684, 78, 'Techs_0_description_copia', 'Asset Liquidity'),
(685, 78, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(686, 78, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(687, 78, '_Techs_0_description', 'field_61cc90eee62b5'),
(688, 78, 'Techs_0_img', '71'),
(689, 78, '_Techs_0_img', 'field_61cc9146162cd'),
(690, 78, 'Techs_1_description_copia', 'Immutable Ledger'),
(691, 78, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(692, 78, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(693, 78, '_Techs_1_description', 'field_61cc90eee62b5'),
(694, 78, 'Techs_1_img', '72'),
(695, 78, '_Techs_1_img', 'field_61cc9146162cd'),
(696, 78, 'Techs_2_description_copia', 'Transparent Ownership'),
(697, 78, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(698, 78, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(699, 78, '_Techs_2_description', 'field_61cc90eee62b5'),
(700, 78, 'Techs_2_img', '73'),
(701, 78, '_Techs_2_img', 'field_61cc9146162cd'),
(702, 78, 'Techs_3_description_copia', 'Digital ID'),
(703, 78, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(704, 78, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(705, 78, '_Techs_3_description', 'field_61cc90eee62b5'),
(706, 78, 'Techs_3_img', '74'),
(707, 78, '_Techs_3_img', 'field_61cc9146162cd'),
(708, 78, 'partners_0_img', '66'),
(709, 78, '_partners_0_img', 'field_61cc919b162d1'),
(710, 78, 'partners_1_img', '67'),
(711, 78, '_partners_1_img', 'field_61cc919b162d1'),
(712, 78, 'partners_2_img', '68'),
(713, 78, '_partners_2_img', 'field_61cc919b162d1'),
(714, 78, 'partners_3_img', '69'),
(715, 78, '_partners_3_img', 'field_61cc919b162d1'),
(716, 78, 'partners_4_img', '70'),
(717, 78, '_partners_4_img', 'field_61cc919b162d1'),
(718, 78, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(719, 78, '_header_button', 'field_61cc8f0ce62a2'),
(720, 79, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(721, 79, '_header_title', 'field_61cc8efbe62a1'),
(722, 79, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(723, 79, '_headet_button', 'field_61cc8f0ce62a2'),
(724, 79, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(725, 79, '_plus_description', 'field_61cc8f28e62a4'),
(726, 79, 'featured_title', 'Featured in'),
(727, 79, '_featured_title', 'field_61cc8f46e62a6'),
(728, 79, 'featureds', '5'),
(729, 79, '_featureds', 'field_61cc8f51e62a7'),
(730, 79, 'investors_title', 'For Investors  and Advisors'),
(731, 79, '_investors_title', 'field_61cc8fe8e62aa'),
(732, 79, 'investors', '3'),
(733, 79, '_investors', 'field_61cc8feee62ab'),
(734, 79, 'founds_title', 'For Fund  Managers'),
(735, 79, '_founds_title', 'field_61cc9064e62b0'),
(736, 79, 'founds', '3'),
(737, 79, '_founds', 'field_61cc9078e62b1'),
(738, 79, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(739, 79, '_tech_title', 'field_61cc90cbe62b3'),
(740, 79, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(741, 79, '_tech_description', 'field_61cc912b162cb'),
(742, 79, 'Techs', '4'),
(743, 79, '_Techs', 'field_61cc90dbe62b4'),
(744, 79, 'partner_title', 'Our Trusted Partners'),
(745, 79, '_partner_title', 'field_61cc9177162cf'),
(746, 79, 'partners', '5'),
(747, 79, '_partners', 'field_61cc918e162d0'),
(748, 79, 'contact_title', 'Contact us to learn more about our services'),
(749, 79, '_contact_title', 'field_61cc91cd8d63b'),
(750, 79, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(751, 79, '_contact_button', 'field_61cc91d68d63c'),
(752, 79, 'featureds_0_img', '59'),
(753, 79, '_featureds_0_img', 'field_61cc8f61e62a8'),
(754, 79, 'featureds_1_img', '60'),
(755, 79, '_featureds_1_img', 'field_61cc8f61e62a8'),
(756, 79, 'featureds_2_img', '61'),
(757, 79, '_featureds_2_img', 'field_61cc8f61e62a8'),
(758, 79, 'featureds_3_img', '62'),
(759, 79, '_featureds_3_img', 'field_61cc8f61e62a8'),
(760, 79, 'featureds_4_img', '63'),
(761, 79, '_featureds_4_img', 'field_61cc8f61e62a8'),
(762, 79, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(763, 79, '_investors_0_description', 'field_61cc901ae62ac'),
(764, 79, 'investors_1_description', 'On-demand professional investment services'),
(765, 79, '_investors_1_description', 'field_61cc901ae62ac'),
(766, 79, 'investors_2_description', 'Unique liquidity management solutions'),
(767, 79, '_investors_2_description', 'field_61cc901ae62ac'),
(768, 79, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(769, 79, '_founds_0_description', 'field_61cc9103e62b6'),
(770, 79, 'founds_1_description', 'Single point of contact for qualified investors'),
(771, 79, '_founds_1_description', 'field_61cc9103e62b6'),
(772, 79, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(773, 79, '_founds_2_description', 'field_61cc9103e62b6'),
(774, 79, 'Techs_0_description_copia', 'Asset Liquidity'),
(775, 79, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(776, 79, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(777, 79, '_Techs_0_description', 'field_61cc90eee62b5'),
(778, 79, 'Techs_0_img', '71') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(779, 79, '_Techs_0_img', 'field_61cc9146162cd'),
(780, 79, 'Techs_1_description_copia', 'Immutable Ledger'),
(781, 79, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(782, 79, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(783, 79, '_Techs_1_description', 'field_61cc90eee62b5'),
(784, 79, 'Techs_1_img', '72'),
(785, 79, '_Techs_1_img', 'field_61cc9146162cd'),
(786, 79, 'Techs_2_description_copia', 'Transparent Ownership'),
(787, 79, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(788, 79, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(789, 79, '_Techs_2_description', 'field_61cc90eee62b5'),
(790, 79, 'Techs_2_img', '73'),
(791, 79, '_Techs_2_img', 'field_61cc9146162cd'),
(792, 79, 'Techs_3_description_copia', 'Digital ID'),
(793, 79, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(794, 79, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(795, 79, '_Techs_3_description', 'field_61cc90eee62b5'),
(796, 79, 'Techs_3_img', '74'),
(797, 79, '_Techs_3_img', 'field_61cc9146162cd'),
(798, 79, 'partners_0_img', '66'),
(799, 79, '_partners_0_img', 'field_61cc919b162d1'),
(800, 79, 'partners_1_img', '67'),
(801, 79, '_partners_1_img', 'field_61cc919b162d1'),
(802, 79, 'partners_2_img', '68'),
(803, 79, '_partners_2_img', 'field_61cc919b162d1'),
(804, 79, 'partners_3_img', '69'),
(805, 79, '_partners_3_img', 'field_61cc919b162d1'),
(806, 79, 'partners_4_img', '70'),
(807, 79, '_partners_4_img', 'field_61cc919b162d1'),
(808, 79, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(809, 79, '_header_button', 'field_61cc8f0ce62a2'),
(810, 2, 'technology_0_title', 'Asset Liquidity'),
(811, 2, '_technology_0_title', 'field_61cc913c162cc'),
(812, 2, 'technology_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(813, 2, '_technology_0_description', 'field_61cc90eee62b5'),
(814, 2, 'technology_0_img', '71'),
(815, 2, '_technology_0_img', 'field_61cc9146162cd'),
(816, 2, 'technology_1_title', 'Immutable Ledger'),
(817, 2, '_technology_1_title', 'field_61cc913c162cc'),
(818, 2, 'technology_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(819, 2, '_technology_1_description', 'field_61cc90eee62b5'),
(820, 2, 'technology_1_img', '73'),
(821, 2, '_technology_1_img', 'field_61cc9146162cd'),
(822, 2, 'technology_2_title', 'Transparent Ownership'),
(823, 2, '_technology_2_title', 'field_61cc913c162cc'),
(824, 2, 'technology_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(825, 2, '_technology_2_description', 'field_61cc90eee62b5'),
(826, 2, 'technology_2_img', '72'),
(827, 2, '_technology_2_img', 'field_61cc9146162cd'),
(828, 2, 'technology_3_title', 'Digital ID'),
(829, 2, '_technology_3_title', 'field_61cc913c162cc'),
(830, 2, 'technology_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(831, 2, '_technology_3_description', 'field_61cc90eee62b5'),
(832, 2, 'technology_3_img', '74'),
(833, 2, '_technology_3_img', 'field_61cc9146162cd'),
(834, 2, 'technology', '4'),
(835, 2, '_technology', 'field_61cc90dbe62b4'),
(836, 80, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(837, 80, '_header_title', 'field_61cc8efbe62a1'),
(838, 80, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(839, 80, '_headet_button', 'field_61cc8f0ce62a2'),
(840, 80, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(841, 80, '_plus_description', 'field_61cc8f28e62a4'),
(842, 80, 'featured_title', 'Featured in'),
(843, 80, '_featured_title', 'field_61cc8f46e62a6'),
(844, 80, 'featureds', '5'),
(845, 80, '_featureds', 'field_61cc8f51e62a7'),
(846, 80, 'investors_title', 'For Investors  and Advisors'),
(847, 80, '_investors_title', 'field_61cc8fe8e62aa'),
(848, 80, 'investors', '3'),
(849, 80, '_investors', 'field_61cc8feee62ab'),
(850, 80, 'founds_title', 'For Fund  Managers'),
(851, 80, '_founds_title', 'field_61cc9064e62b0'),
(852, 80, 'founds', '3'),
(853, 80, '_founds', 'field_61cc9078e62b1'),
(854, 80, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(855, 80, '_tech_title', 'field_61cc90cbe62b3'),
(856, 80, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(857, 80, '_tech_description', 'field_61cc912b162cb'),
(858, 80, 'Techs', '4'),
(859, 80, '_Techs', 'field_61cc90dbe62b4'),
(860, 80, 'partner_title', 'Our Trusted Partners'),
(861, 80, '_partner_title', 'field_61cc9177162cf'),
(862, 80, 'partners', '5'),
(863, 80, '_partners', 'field_61cc918e162d0'),
(864, 80, 'contact_title', 'Contact us to learn more about our services'),
(865, 80, '_contact_title', 'field_61cc91cd8d63b'),
(866, 80, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(867, 80, '_contact_button', 'field_61cc91d68d63c'),
(868, 80, 'featureds_0_img', '59'),
(869, 80, '_featureds_0_img', 'field_61cc8f61e62a8'),
(870, 80, 'featureds_1_img', '60'),
(871, 80, '_featureds_1_img', 'field_61cc8f61e62a8'),
(872, 80, 'featureds_2_img', '61'),
(873, 80, '_featureds_2_img', 'field_61cc8f61e62a8'),
(874, 80, 'featureds_3_img', '62'),
(875, 80, '_featureds_3_img', 'field_61cc8f61e62a8'),
(876, 80, 'featureds_4_img', '63'),
(877, 80, '_featureds_4_img', 'field_61cc8f61e62a8'),
(878, 80, 'investors_0_description', 'Simplified access to world-class managers and strategies') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(879, 80, '_investors_0_description', 'field_61cc901ae62ac'),
(880, 80, 'investors_1_description', 'On-demand professional investment services'),
(881, 80, '_investors_1_description', 'field_61cc901ae62ac'),
(882, 80, 'investors_2_description', 'Unique liquidity management solutions'),
(883, 80, '_investors_2_description', 'field_61cc901ae62ac'),
(884, 80, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(885, 80, '_founds_0_description', 'field_61cc9103e62b6'),
(886, 80, 'founds_1_description', 'Single point of contact for qualified investors'),
(887, 80, '_founds_1_description', 'field_61cc9103e62b6'),
(888, 80, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(889, 80, '_founds_2_description', 'field_61cc9103e62b6'),
(890, 80, 'Techs_0_description_copia', 'Asset Liquidity'),
(891, 80, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(892, 80, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(893, 80, '_Techs_0_description', 'field_61cc90eee62b5'),
(894, 80, 'Techs_0_img', '71'),
(895, 80, '_Techs_0_img', 'field_61cc9146162cd'),
(896, 80, 'Techs_1_description_copia', 'Immutable Ledger'),
(897, 80, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(898, 80, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(899, 80, '_Techs_1_description', 'field_61cc90eee62b5'),
(900, 80, 'Techs_1_img', '72'),
(901, 80, '_Techs_1_img', 'field_61cc9146162cd'),
(902, 80, 'Techs_2_description_copia', 'Transparent Ownership'),
(903, 80, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(904, 80, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(905, 80, '_Techs_2_description', 'field_61cc90eee62b5'),
(906, 80, 'Techs_2_img', '73'),
(907, 80, '_Techs_2_img', 'field_61cc9146162cd'),
(908, 80, 'Techs_3_description_copia', 'Digital ID'),
(909, 80, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(910, 80, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(911, 80, '_Techs_3_description', 'field_61cc90eee62b5'),
(912, 80, 'Techs_3_img', '74'),
(913, 80, '_Techs_3_img', 'field_61cc9146162cd'),
(914, 80, 'partners_0_img', '66'),
(915, 80, '_partners_0_img', 'field_61cc919b162d1'),
(916, 80, 'partners_1_img', '67'),
(917, 80, '_partners_1_img', 'field_61cc919b162d1'),
(918, 80, 'partners_2_img', '68'),
(919, 80, '_partners_2_img', 'field_61cc919b162d1'),
(920, 80, 'partners_3_img', '69'),
(921, 80, '_partners_3_img', 'field_61cc919b162d1'),
(922, 80, 'partners_4_img', '70'),
(923, 80, '_partners_4_img', 'field_61cc919b162d1'),
(924, 80, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(925, 80, '_header_button', 'field_61cc8f0ce62a2'),
(926, 80, 'technology_0_title', 'Asset Liquidity'),
(927, 80, '_technology_0_title', 'field_61cc913c162cc'),
(928, 80, 'technology_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(929, 80, '_technology_0_description', 'field_61cc90eee62b5'),
(930, 80, 'technology_0_img', '71'),
(931, 80, '_technology_0_img', 'field_61cc9146162cd'),
(932, 80, 'technology_1_title', 'Immutable Ledger'),
(933, 80, '_technology_1_title', 'field_61cc913c162cc'),
(934, 80, 'technology_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(935, 80, '_technology_1_description', 'field_61cc90eee62b5'),
(936, 80, 'technology_1_img', '73'),
(937, 80, '_technology_1_img', 'field_61cc9146162cd'),
(938, 80, 'technology_2_title', 'Transparent Ownership'),
(939, 80, '_technology_2_title', 'field_61cc913c162cc'),
(940, 80, 'technology_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(941, 80, '_technology_2_description', 'field_61cc90eee62b5'),
(942, 80, 'technology_2_img', '72'),
(943, 80, '_technology_2_img', 'field_61cc9146162cd'),
(944, 80, 'technology_3_title', 'Digital ID'),
(945, 80, '_technology_3_title', 'field_61cc913c162cc'),
(946, 80, 'technology_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(947, 80, '_technology_3_description', 'field_61cc90eee62b5'),
(948, 80, 'technology_3_img', '74'),
(949, 80, '_technology_3_img', 'field_61cc9146162cd'),
(950, 80, 'technology', '4'),
(951, 80, '_technology', 'field_61cc90dbe62b4'),
(952, 81, 'header_title', 'The next generation <br>marketplace for <br>private investments'),
(953, 81, '_header_title', 'field_61cc8efbe62a1'),
(954, 81, 'headet_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(955, 81, '_headet_button', 'field_61cc8f0ce62a2'),
(956, 81, 'plus_description', 'Connecting world-class fund managers with qualified investors and their advisors using proprietary blockchain technology.'),
(957, 81, '_plus_description', 'field_61cc8f28e62a4'),
(958, 81, 'featured_title', 'Featured in'),
(959, 81, '_featured_title', 'field_61cc8f46e62a6'),
(960, 81, 'featureds', '5'),
(961, 81, '_featureds', 'field_61cc8f51e62a7'),
(962, 81, 'investors_title', 'For Investors and Advisors'),
(963, 81, '_investors_title', 'field_61cc8fe8e62aa'),
(964, 81, 'investors', '3'),
(965, 81, '_investors', 'field_61cc8feee62ab'),
(966, 81, 'founds_title', 'For Fund Managers'),
(967, 81, '_founds_title', 'field_61cc9064e62b0'),
(968, 81, 'founds', '3'),
(969, 81, '_founds', 'field_61cc9078e62b1'),
(970, 81, 'tech_title', 'Tokenized investment products using proprietary blockchain technology'),
(971, 81, '_tech_title', 'field_61cc90cbe62b3'),
(972, 81, 'tech_description', 'Our smart security token allows for complex financial instruments to be modeled in a simple programming language and fully digitized onto a secured private distributed ledger.'),
(973, 81, '_tech_description', 'field_61cc912b162cb'),
(974, 81, 'Techs', '4'),
(975, 81, '_Techs', 'field_61cc90dbe62b4'),
(976, 81, 'partner_title', 'Our Trusted Partners'),
(977, 81, '_partner_title', 'field_61cc9177162cf'),
(978, 81, 'partners', '5') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(979, 81, '_partners', 'field_61cc918e162d0'),
(980, 81, 'contact_title', 'Contact us to learn more about our services'),
(981, 81, '_contact_title', 'field_61cc91cd8d63b'),
(982, 81, 'contact_button', 'a:3:{s:5:"title";s:10:"Contact us";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(983, 81, '_contact_button', 'field_61cc91d68d63c'),
(984, 81, 'featureds_0_img', '59'),
(985, 81, '_featureds_0_img', 'field_61cc8f61e62a8'),
(986, 81, 'featureds_1_img', '60'),
(987, 81, '_featureds_1_img', 'field_61cc8f61e62a8'),
(988, 81, 'featureds_2_img', '61'),
(989, 81, '_featureds_2_img', 'field_61cc8f61e62a8'),
(990, 81, 'featureds_3_img', '62'),
(991, 81, '_featureds_3_img', 'field_61cc8f61e62a8'),
(992, 81, 'featureds_4_img', '63'),
(993, 81, '_featureds_4_img', 'field_61cc8f61e62a8'),
(994, 81, 'investors_0_description', 'Simplified access to world-class managers and strategies'),
(995, 81, '_investors_0_description', 'field_61cc901ae62ac'),
(996, 81, 'investors_1_description', 'On-demand professional investment services'),
(997, 81, '_investors_1_description', 'field_61cc901ae62ac'),
(998, 81, 'investors_2_description', 'Unique liquidity management solutions'),
(999, 81, '_investors_2_description', 'field_61cc901ae62ac'),
(1000, 81, 'founds_0_description', 'Quick setup of fully compliant distribution vehicle'),
(1001, 81, '_founds_0_description', 'field_61cc9103e62b6'),
(1002, 81, 'founds_1_description', 'Single point of contact for qualified investors'),
(1003, 81, '_founds_1_description', 'field_61cc9103e62b6'),
(1004, 81, 'founds_2_description', 'Real-time marketing and sales analytics for efficient fundraising'),
(1005, 81, '_founds_2_description', 'field_61cc9103e62b6'),
(1006, 81, 'Techs_0_description_copia', 'Asset Liquidity'),
(1007, 81, '_Techs_0_description_copia', 'field_61cc913c162cc'),
(1008, 81, 'Techs_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(1009, 81, '_Techs_0_description', 'field_61cc90eee62b5'),
(1010, 81, 'Techs_0_img', '71'),
(1011, 81, '_Techs_0_img', 'field_61cc9146162cd'),
(1012, 81, 'Techs_1_description_copia', 'Immutable Ledger'),
(1013, 81, '_Techs_1_description_copia', 'field_61cc913c162cc'),
(1014, 81, 'Techs_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(1015, 81, '_Techs_1_description', 'field_61cc90eee62b5'),
(1016, 81, 'Techs_1_img', '72'),
(1017, 81, '_Techs_1_img', 'field_61cc9146162cd'),
(1018, 81, 'Techs_2_description_copia', 'Transparent Ownership'),
(1019, 81, '_Techs_2_description_copia', 'field_61cc913c162cc'),
(1020, 81, 'Techs_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(1021, 81, '_Techs_2_description', 'field_61cc90eee62b5'),
(1022, 81, 'Techs_2_img', '73'),
(1023, 81, '_Techs_2_img', 'field_61cc9146162cd'),
(1024, 81, 'Techs_3_description_copia', 'Digital ID'),
(1025, 81, '_Techs_3_description_copia', 'field_61cc913c162cc'),
(1026, 81, 'Techs_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(1027, 81, '_Techs_3_description', 'field_61cc90eee62b5'),
(1028, 81, 'Techs_3_img', '74'),
(1029, 81, '_Techs_3_img', 'field_61cc9146162cd'),
(1030, 81, 'partners_0_img', '66'),
(1031, 81, '_partners_0_img', 'field_61cc919b162d1'),
(1032, 81, 'partners_1_img', '67'),
(1033, 81, '_partners_1_img', 'field_61cc919b162d1'),
(1034, 81, 'partners_2_img', '68'),
(1035, 81, '_partners_2_img', 'field_61cc919b162d1'),
(1036, 81, 'partners_3_img', '69'),
(1037, 81, '_partners_3_img', 'field_61cc919b162d1'),
(1038, 81, 'partners_4_img', '70'),
(1039, 81, '_partners_4_img', 'field_61cc919b162d1'),
(1040, 81, 'header_button', 'a:3:{s:5:"title";s:10:"Learn more";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(1041, 81, '_header_button', 'field_61cc8f0ce62a2'),
(1042, 81, 'technology_0_title', 'Asset Liquidity'),
(1043, 81, '_technology_0_title', 'field_61cc913c162cc'),
(1044, 81, 'technology_0_description', 'Convert illiquid assets into a highly efficient and cost effective exchange tradable product.'),
(1045, 81, '_technology_0_description', 'field_61cc90eee62b5'),
(1046, 81, 'technology_0_img', '71'),
(1047, 81, '_technology_0_img', 'field_61cc9146162cd'),
(1048, 81, 'technology_1_title', 'Immutable Ledger'),
(1049, 81, '_technology_1_title', 'field_61cc913c162cc'),
(1050, 81, 'technology_1_description', 'Providing seamless operational support and integrity through a permanent, tamper-proof private blockchain.'),
(1051, 81, '_technology_1_description', 'field_61cc90eee62b5'),
(1052, 81, 'technology_1_img', '73'),
(1053, 81, '_technology_1_img', 'field_61cc9146162cd'),
(1054, 81, 'technology_2_title', 'Transparent Ownership'),
(1055, 81, '_technology_2_title', 'field_61cc913c162cc'),
(1056, 81, 'technology_2_description', '"Smart Certificates" authenticate sale and transfer for full transparency and accountability.'),
(1057, 81, '_technology_2_description', 'field_61cc90eee62b5'),
(1058, 81, 'technology_2_img', '72'),
(1059, 81, '_technology_2_img', 'field_61cc9146162cd'),
(1060, 81, 'technology_3_title', 'Digital ID'),
(1061, 81, '_technology_3_title', 'field_61cc913c162cc'),
(1062, 81, 'technology_3_description', 'A proprietary platform developed by seasoned professionals in the fields of finance and technology.'),
(1063, 81, '_technology_3_description', 'field_61cc90eee62b5'),
(1064, 81, 'technology_3_img', '74'),
(1065, 81, '_technology_3_img', 'field_61cc9146162cd'),
(1066, 81, 'technology', '4'),
(1067, 81, '_technology', 'field_61cc90dbe62b4'),
(1068, 82, '_menu_item_type', 'custom'),
(1069, 82, '_menu_item_menu_item_parent', '0'),
(1070, 82, '_menu_item_object_id', '82'),
(1071, 82, '_menu_item_object', 'custom'),
(1072, 82, '_menu_item_target', ''),
(1073, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1074, 82, '_menu_item_xfn', ''),
(1075, 82, '_menu_item_url', '#'),
(1077, 83, '_menu_item_type', 'custom'),
(1078, 83, '_menu_item_menu_item_parent', '0'),
(1079, 83, '_menu_item_object_id', '83') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1080, 83, '_menu_item_object', 'custom'),
(1081, 83, '_menu_item_target', ''),
(1082, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1083, 83, '_menu_item_xfn', ''),
(1084, 83, '_menu_item_url', '#'),
(1086, 84, '_menu_item_type', 'custom'),
(1087, 84, '_menu_item_menu_item_parent', '0'),
(1088, 84, '_menu_item_object_id', '84'),
(1089, 84, '_menu_item_object', 'custom'),
(1090, 84, '_menu_item_target', ''),
(1091, 84, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1092, 84, '_menu_item_xfn', ''),
(1093, 84, '_menu_item_url', '#'),
(1095, 85, '_menu_item_type', 'custom'),
(1096, 85, '_menu_item_menu_item_parent', '0'),
(1097, 85, '_menu_item_object_id', '85'),
(1098, 85, '_menu_item_object', 'custom'),
(1099, 85, '_menu_item_target', ''),
(1100, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1101, 85, '_menu_item_xfn', ''),
(1102, 85, '_menu_item_url', '#'),
(1104, 86, '_menu_item_type', 'custom'),
(1105, 86, '_menu_item_menu_item_parent', '0'),
(1106, 86, '_menu_item_object_id', '86'),
(1107, 86, '_menu_item_object', 'custom'),
(1108, 86, '_menu_item_target', ''),
(1109, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1110, 86, '_menu_item_xfn', ''),
(1111, 86, '_menu_item_url', '#') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-12-26 22:37:37', '2021-12-26 21:37:37', '<!-- wp:paragraph -->\n<p>Ti diamo il benvenuto in WordPress. Questo è il tuo primo articolo. Modificalo o cancellalo e quindi inizia a scrivere!</p>\n<!-- /wp:paragraph -->', 'Ciao mondo!', '', 'publish', 'open', 'open', '', 'ciao-mondo', '', '', '2021-12-26 22:37:37', '2021-12-26 21:37:37', '', 0, 'http://privatemarket.io/?p=1', 0, 'post', '', 1),
(2, 1, '2021-12-26 22:37:37', '2021-12-26 21:37:37', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-01-01 11:36:55', '2022-01-01 10:36:55', '', 0, 'http://privatemarket.io/?page_id=2', -1, 'page', '', 0),
(3, 1, '2021-12-26 22:37:37', '2021-12-26 21:37:37', '<!-- wp:heading --><h2>Chi siamo</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>L\'indirizzo del nostro sito web è: http://privatemarket.io.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Commenti</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Quando i visitatori lasciano commenti sul sito, raccogliamo i dati mostrati nel modulo dei commenti oltre all\'indirizzo IP del visitatore e la stringa dello user agent del browser per facilitare il rilevamento dello spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Una stringa anonimizzata creata a partire dal tuo indirizzo email (altrimenti detta hash) può essere fornita al servizio Gravatar per vedere se lo stai usando. La privacy policy del servizio Gravatar è disponibile qui: https://automattic.com/privacy/. Dopo l\'approvazione del tuo commento, la tua immagine del profilo è visibile al pubblico nel contesto del tuo commento.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Se carichi immagini sul sito web, dovresti evitare di caricare immagini che includono i dati di posizione incorporati (EXIF GPS). I visitatori del sito web possono scaricare ed estrarre qualsiasi dato sulla posizione dalle immagini sul sito web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Se lasci un commento sul nostro sito, puoi scegliere di salvare il tuo nome, indirizzo email e sito web nei cookie. Sono usati per la tua comodità in modo che tu non debba inserire nuovamente i tuoi dati quando lasci un altro commento. Questi cookie dureranno per un anno.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se visiti la pagina di login, verrà impostato un cookie temporaneo per determinare se il tuo browser accetta i cookie. Questo cookie non contiene dati personali e viene eliminato quando chiudi il browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Quando effettui l\'accesso, verranno impostati diversi cookie per salvare le tue informazioni di accesso e le tue opzioni di visualizzazione dello schermo. I cookie di accesso durano due giorni mentre i cookie per le opzioni dello schermo durano un anno. Se selezioni &quot;Ricordami&quot;, il tuo accesso persisterà per due settimane. Se esci dal tuo account, i cookie di accesso verranno rimossi.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se modifichi o pubblichi un articolo, un cookie aggiuntivo verrà salvato nel tuo browser. Questo cookie non include dati personali, ma indica semplicemente l\'ID dell\'articolo appena modificato. Scade dopo 1 giorno.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Contenuto incorporato da altri siti web</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Gli articoli su questo sito possono includere contenuti incorporati (ad esempio video, immagini, articoli, ecc.). I contenuti incorporati da altri siti web si comportano esattamente allo stesso modo come se il visitatore avesse visitato l\'altro sito web.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Questi siti web possono raccogliere dati su di te, usare cookie, integrare ulteriori tracciamenti di terze parti e monitorare l\'interazione con essi, incluso il tracciamento della tua interazione con il contenuto incorporato se hai un account e sei connesso a quei siti web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Con chi condividiamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Se richiedi una reimpostazione della password, il tuo indirizzo IP verrà incluso nell\'email di reimpostazione.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Per quanto tempo conserviamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Se lasci un commento, il commento e i relativi metadati vengono conservati a tempo indeterminato. È così che possiamo riconoscere e approvare automaticamente eventuali commenti successivi invece di tenerli in una coda di moderazione.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Per gli utenti che si registrano sul nostro sito web (se presenti), memorizziamo anche le informazioni personali che forniscono nel loro profilo utente. Tutti gli utenti possono vedere, modificare o cancellare le loro informazioni personali in qualsiasi momento (eccetto il loro nome utente che non possono cambiare). Gli amministratori del sito web possono anche vedere e modificare queste informazioni.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quali diritti hai sui tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>Se hai un account su questo sito, o hai lasciato commenti, puoi richiedere di ricevere un file esportato dal sito con i dati personali che abbiamo su di te, compresi i dati che ci hai fornito. Puoi anche richiedere che cancelliamo tutti i dati personali che ti riguardano. Questo non include i dati che siamo obbligati a conservare per scopi amministrativi, legali o di sicurezza.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Dove spediamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Testo suggerito: </strong>I commenti dei visitatori possono essere controllati attraverso un servizio di rilevamento automatico dello spam.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-12-26 22:37:37', '2021-12-26 21:37:37', '', 0, 'http://privatemarket.io/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-12-26 22:39:34', '0000-00-00 00:00:00', '', 'Bozza automatica', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-12-26 22:39:34', '0000-00-00 00:00:00', '', 0, 'http://privatemarket.io/?p=4', 0, 'post', '', 0),
(5, 1, '2021-12-26 23:02:23', '2021-12-26 22:02:23', '{"privatemarket\\/resources::nav_menu_locations[primary_navigation]":{"value":-918811337944309800,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-26 22:02:23"},"nav_menu[-918811337944309800]":{"value":{"name":"Primary","description":"","parent":0,"auto_add":false},"type":"nav_menu","user_id":1,"date_modified_gmt":"2021-12-26 22:02:23"},"nav_menu_item[-8471592183778425000]":{"value":{"object_id":0,"object":"","menu_item_parent":0,"position":1,"type":"custom","title":"Home","url":"http:\\/\\/privatemarket.io","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":-918811337944309800,"_invalid":false,"type_label":"Link personalizzato"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-26 22:02:23"},"nav_menu_item[-931840797671864300]":{"value":{"object_id":2,"object":"page","menu_item_parent":0,"position":2,"type":"post_type","title":"Pagina di esempio","url":"http:\\/\\/privatemarket.io\\/pagina-di-esempio\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Pagina di esempio","nav_menu_term_id":-918811337944309800,"_invalid":false,"type_label":"Pagina"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-26 22:02:23"}}', '', '', 'trash', 'closed', 'closed', '', 'b6e5fa3d-b7fb-4b5f-9864-30b28d2f509e', '', '', '2021-12-26 23:02:23', '2021-12-26 22:02:23', '', 0, 'http://privatemarket.io/2021/12/26/b6e5fa3d-b7fb-4b5f-9864-30b28d2f509e/', 0, 'customize_changeset', '', 0),
(8, 1, '2021-12-29 16:14:19', '2021-12-29 15:14:19', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-29 16:14:19', '2021-12-29 15:14:19', '', 2, 'http://privatemarket.io/?p=8', 0, 'revision', '', 0),
(9, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/about/', 0, 'page', '', 0),
(10, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/blog/', 0, 'page', '', 0),
(11, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'Contatti', '', 'publish', 'closed', 'closed', '', 'contatti', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/contatti/', 0, 'page', '', 0),
(12, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'Privacy Policy GDPR', '', 'publish', 'closed', 'closed', '', 'privacy-policy-gdpr', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/privacy-policy-gdpr/', 0, 'page', '', 0),
(13, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'Cookie Policy GDPR', '', 'publish', 'closed', 'closed', '', 'cookie-policy-gdpr', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/cookie-policy-gdpr/', 0, 'page', '', 0),
(14, 1, '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 'Cerca', '', 'publish', 'closed', 'closed', '', 'cerca', '', '', '2021-12-29 16:14:28', '2021-12-29 15:14:28', '', 0, 'http://privatemarket.io/cerca/', 0, 'page', '', 0),
(23, 1, '2021-12-29 16:18:49', '2021-12-29 15:18:49', '{"a5tratto-theme-child::a5t_setting_bootstrap":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_fa":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_animate":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_hover":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_owl_carousel":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_jarallax":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_nprogress":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"},"a5tratto-theme-child::a5t_setting_gototop":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:18:49"}}', '', '', 'trash', 'closed', 'closed', '', '6eace7fb-c233-4e61-b901-69fb5627b61f', '', '', '2021-12-29 16:18:49', '2021-12-29 15:18:49', '', 0, 'http://privatemarket.io/6eace7fb-c233-4e61-b901-69fb5627b61f/', 0, 'customize_changeset', '', 0),
(24, 1, '2021-12-29 16:19:01', '2021-12-29 15:19:01', '{"a5tratto-theme-child::a5t_adv_twig":{"value":true,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-12-29 15:19:01"}}', '', '', 'trash', 'closed', 'closed', '', '8bb71ef0-2c39-441e-9a3e-1558697a4b63', '', '', '2021-12-29 16:19:01', '2021-12-29 15:19:01', '', 0, 'http://privatemarket.io/8bb71ef0-2c39-441e-9a3e-1558697a4b63/', 0, 'customize_changeset', '', 0),
(25, 1, '2021-12-29 16:19:32', '2021-12-29 15:19:32', '{"nav_menu_item[15]":{"value":{"menu_item_parent":0,"object_id":9,"object":"page","type":"post_type","type_label":"Pagina","url":"http:\\/\\/privatemarket.io\\/about\\/","title":"","target":"","attr_title":"","description":"","classes":"","xfn":"","nav_menu_term_id":3,"position":2,"status":"publish","original_title":"About","_invalid":false},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[16]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[17]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[18]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[19]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[20]":{"value":{"menu_item_parent":0,"object_id":2,"object":"page","type":"post_type","type_label":"Home page","url":"http:\\/\\/privatemarket.io\\/","title":"","target":"","attr_title":"","description":"","classes":"","xfn":"","nav_menu_term_id":3,"position":1,"status":"publish","original_title":"Home","_invalid":false},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"},"nav_menu_item[21]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2021-12-29 15:19:32"}}', '', '', 'trash', 'closed', 'closed', '', 'a2d23982-c3d1-4ba7-9dd6-766933c39995', '', '', '2021-12-29 16:19:32', '2021-12-29 15:19:32', '', 0, 'http://privatemarket.io/a2d23982-c3d1-4ba7-9dd6-766933c39995/', 0, 'customize_changeset', '', 0),
(26, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:23:"template-home-child.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Page Home', 'page-home', 'publish', 'closed', 'closed', '', 'group_61cc8eed02d47', '', '', '2021-12-30 00:40:45', '2021-12-29 23:40:45', '', 0, 'http://privatemarket.io/?post_type=acf-field-group&#038;p=26', 0, 'acf-field-group', '', 0),
(27, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header', 'header', 'publish', 'closed', 'closed', '', 'field_61cc8ef2e62a0', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Header Title', 'header_title', 'publish', 'closed', 'closed', '', 'field_61cc8efbe62a1', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Header Button', 'header_button', 'publish', 'closed', 'closed', '', 'field_61cc8f0ce62a2', '', '', '2021-12-30 00:23:00', '2021-12-29 23:23:00', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=29', 2, 'acf-field', '', 0),
(30, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Plus', 'plus', 'publish', 'closed', 'closed', '', 'field_61cc8f16e62a3', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=30', 3, 'acf-field', '', 0),
(31, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Plus Description', 'plus_description', 'publish', 'closed', 'closed', '', 'field_61cc8f28e62a4', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=31', 4, 'acf-field', '', 0),
(32, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Featured', 'featured', 'publish', 'closed', 'closed', '', 'field_61cc8f37e62a5', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=32', 5, 'acf-field', '', 0),
(33, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Featured Title', 'featured_title', 'publish', 'closed', 'closed', '', 'field_61cc8f46e62a6', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=33', 6, 'acf-field', '', 0),
(34, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Featureds', 'featureds', 'publish', 'closed', 'closed', '', 'field_61cc8f51e62a7', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=34', 7, 'acf-field', '', 0),
(35, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Img', 'img', 'publish', 'closed', 'closed', '', 'field_61cc8f61e62a8', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 34, 'http://privatemarket.io/?post_type=acf-field&p=35', 0, 'acf-field', '', 0),
(36, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'ADV', 'for', 'publish', 'closed', 'closed', '', 'field_61cc902de62ae', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=36', 8, 'acf-field', '', 0),
(37, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Investors Title', 'investors_title', 'publish', 'closed', 'closed', '', 'field_61cc8fe8e62aa', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=37', 9, 'acf-field', '', 0),
(38, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Investors', 'investors', 'publish', 'closed', 'closed', '', 'field_61cc8feee62ab', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=38', 10, 'acf-field', '', 0),
(39, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_61cc901ae62ac', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 38, 'http://privatemarket.io/?post_type=acf-field&p=39', 0, 'acf-field', '', 0),
(40, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Found', 'found', 'publish', 'closed', 'closed', '', 'field_61cc9042e62af', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=40', 11, 'acf-field', '', 0),
(41, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Founds Title', 'founds_title', 'publish', 'closed', 'closed', '', 'field_61cc9064e62b0', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=41', 12, 'acf-field', '', 0),
(42, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Founds', 'founds', 'publish', 'closed', 'closed', '', 'field_61cc9078e62b1', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=42', 13, 'acf-field', '', 0),
(43, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_61cc9103e62b6', '', '', '2021-12-29 17:47:15', '2021-12-29 16:47:15', '', 42, 'http://privatemarket.io/?post_type=acf-field&p=43', 0, 'acf-field', '', 0),
(44, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Tech', 'tech', 'publish', 'closed', 'closed', '', 'field_61cc9099e62b2', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=44', 14, 'acf-field', '', 0),
(45, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Tech Title', 'tech_title', 'publish', 'closed', 'closed', '', 'field_61cc90cbe62b3', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=45', 15, 'acf-field', '', 0),
(46, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Technology', 'technology', 'publish', 'closed', 'closed', '', 'field_61cc90dbe62b4', '', '', '2021-12-30 00:40:45', '2021-12-29 23:40:45', '', 26, 'http://privatemarket.io/?post_type=acf-field&#038;p=46', 17, 'acf-field', '', 0),
(47, 1, '2021-12-29 17:47:15', '2021-12-29 16:47:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_61cc90eee62b5', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 46, 'http://privatemarket.io/?post_type=acf-field&#038;p=47', 1, 'acf-field', '', 0),
(48, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Tech Description', 'tech_description', 'publish', 'closed', 'closed', '', 'field_61cc912b162cb', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=48', 16, 'acf-field', '', 0),
(49, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_61cc913c162cc', '', '', '2021-12-30 00:40:45', '2021-12-29 23:40:45', '', 46, 'http://privatemarket.io/?post_type=acf-field&#038;p=49', 0, 'acf-field', '', 0),
(50, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Img', 'img', 'publish', 'closed', 'closed', '', 'field_61cc9146162cd', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 46, 'http://privatemarket.io/?post_type=acf-field&p=50', 2, 'acf-field', '', 0),
(51, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Partner', '_copia', 'publish', 'closed', 'closed', '', 'field_61cc9164162ce', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=51', 18, 'acf-field', '', 0),
(52, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Partner Title', 'partner_title', 'publish', 'closed', 'closed', '', 'field_61cc9177162cf', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=52', 19, 'acf-field', '', 0),
(53, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Partners', 'partners', 'publish', 'closed', 'closed', '', 'field_61cc918e162d0', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=53', 20, 'acf-field', '', 0),
(54, 1, '2021-12-29 17:49:46', '2021-12-29 16:49:46', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Img', 'img', 'publish', 'closed', 'closed', '', 'field_61cc919b162d1', '', '', '2021-12-29 17:49:46', '2021-12-29 16:49:46', '', 53, 'http://privatemarket.io/?post_type=acf-field&p=54', 0, 'acf-field', '', 0),
(55, 1, '2021-12-29 17:50:45', '2021-12-29 16:50:45', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Contact', 'contact', 'publish', 'closed', 'closed', '', 'field_61cc91b48d63a', '', '', '2021-12-29 17:50:45', '2021-12-29 16:50:45', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=55', 21, 'acf-field', '', 0),
(56, 1, '2021-12-29 17:50:45', '2021-12-29 16:50:45', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Title', 'contact_title', 'publish', 'closed', 'closed', '', 'field_61cc91cd8d63b', '', '', '2021-12-29 17:50:45', '2021-12-29 16:50:45', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=56', 22, 'acf-field', '', 0),
(57, 1, '2021-12-29 17:50:45', '2021-12-29 16:50:45', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Contact Button', 'contact_button', 'publish', 'closed', 'closed', '', 'field_61cc91d68d63c', '', '', '2021-12-29 17:50:45', '2021-12-29 16:50:45', '', 26, 'http://privatemarket.io/?post_type=acf-field&p=57', 23, 'acf-field', '', 0),
(58, 1, '2021-12-29 18:21:18', '2021-12-29 17:21:18', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-a5tratto-theme-child', '', '', '2021-12-29 18:21:18', '2021-12-29 17:21:18', '', 0, 'http://privatemarket.io/wp-global-styles-a5tratto-theme-child/', 0, 'wp_global_styles', '', 0),
(59, 1, '2021-12-29 18:24:14', '2021-12-29 17:24:14', '', 'avcj', '', 'inherit', 'open', 'closed', '', 'avcj', '', '', '2021-12-29 18:24:14', '2021-12-29 17:24:14', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2021-12-29 18:24:16', '2021-12-29 17:24:16', '', 'bitcoinmagazine', '', 'inherit', 'open', 'closed', '', 'bitcoinmagazine', '', '', '2021-12-29 18:24:16', '2021-12-29 17:24:16', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2021-12-29 18:24:17', '2021-12-29 17:24:17', '', 'businesswire', '', 'inherit', 'open', 'closed', '', 'businesswire', '', '', '2021-12-29 18:24:17', '2021-12-29 17:24:17', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire.png', 0, 'attachment', 'image/png', 0),
(62, 1, '2021-12-29 18:24:19', '2021-12-29 17:24:19', '', 'cnn', '', 'inherit', 'open', 'closed', '', 'cnn', '', '', '2021-12-29 18:24:19', '2021-12-29 17:24:19', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn.png', 0, 'attachment', 'image/png', 0),
(63, 1, '2021-12-29 18:24:21', '2021-12-29 17:24:21', '', 'finextra', '', 'inherit', 'open', 'closed', '', 'finextra', '', '', '2021-12-29 18:24:21', '2021-12-29 17:24:21', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2021-12-29 18:24:29', '2021-12-29 17:24:29', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-29 18:24:29', '2021-12-29 17:24:29', '', 2, 'http://privatemarket.io/?p=64', 0, 'revision', '', 0),
(65, 1, '2021-12-29 18:38:51', '2021-12-29 17:38:51', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-29 18:38:51', '2021-12-29 17:38:51', '', 2, 'http://privatemarket.io/?p=65', 0, 'revision', '', 0),
(66, 1, '2021-12-30 00:17:44', '2021-12-29 23:17:44', '', 'avcj', '', 'inherit', 'open', 'closed', '', 'avcj-2', '', '', '2021-12-30 00:17:44', '2021-12-29 23:17:44', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj-1.png', 0, 'attachment', 'image/png', 0),
(67, 1, '2021-12-30 00:17:46', '2021-12-29 23:17:46', '', 'bitcoinmagazine', '', 'inherit', 'open', 'closed', '', 'bitcoinmagazine-2', '', '', '2021-12-30 00:17:46', '2021-12-29 23:17:46', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine-1.png', 0, 'attachment', 'image/png', 0),
(68, 1, '2021-12-30 00:17:48', '2021-12-29 23:17:48', '', 'businesswire', '', 'inherit', 'open', 'closed', '', 'businesswire-2', '', '', '2021-12-30 00:17:48', '2021-12-29 23:17:48', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire-1.png', 0, 'attachment', 'image/png', 0),
(69, 1, '2021-12-30 00:17:49', '2021-12-29 23:17:49', '', 'cnn', '', 'inherit', 'open', 'closed', '', 'cnn-2', '', '', '2021-12-30 00:17:49', '2021-12-29 23:17:49', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn-1.png', 0, 'attachment', 'image/png', 0),
(70, 1, '2021-12-30 00:17:51', '2021-12-29 23:17:51', '', 'finextra', '', 'inherit', 'open', 'closed', '', 'finextra-2', '', '', '2021-12-30 00:17:51', '2021-12-29 23:17:51', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra-1.png', 0, 'attachment', 'image/png', 0),
(71, 1, '2021-12-30 00:19:50', '2021-12-29 23:19:50', '', 'box1', '', 'inherit', 'open', 'closed', '', 'box1', '', '', '2021-12-30 00:19:50', '2021-12-29 23:19:50', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/box1.png', 0, 'attachment', 'image/png', 0),
(72, 1, '2021-12-30 00:19:56', '2021-12-29 23:19:56', '', 'box2', '', 'inherit', 'open', 'closed', '', 'box2', '', '', '2021-12-30 00:19:56', '2021-12-29 23:19:56', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/box2.png', 0, 'attachment', 'image/png', 0),
(73, 1, '2021-12-30 00:20:04', '2021-12-29 23:20:04', '', 'box3', '', 'inherit', 'open', 'closed', '', 'box3', '', '', '2021-12-30 00:20:04', '2021-12-29 23:20:04', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/box3.png', 0, 'attachment', 'image/png', 0),
(74, 1, '2021-12-30 00:20:12', '2021-12-29 23:20:12', '', 'box4', '', 'inherit', 'open', 'closed', '', 'box4', '', '', '2021-12-30 00:20:12', '2021-12-29 23:20:12', '', 2, 'http://privatemarket.io/wp-content/uploads/2021/12/box4.png', 0, 'attachment', 'image/png', 0),
(75, 1, '2021-12-30 00:22:37', '2021-12-29 23:22:37', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-30 00:22:37', '2021-12-29 23:22:37', '', 2, 'http://privatemarket.io/?p=75', 0, 'revision', '', 0),
(76, 1, '2021-12-30 00:24:20', '2021-12-29 23:24:20', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-30 00:24:20', '2021-12-29 23:24:20', '', 2, 'http://privatemarket.io/?p=76', 0, 'revision', '', 0),
(77, 1, '2021-12-30 00:35:18', '2021-12-29 23:35:18', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-30 00:35:18', '2021-12-29 23:35:18', '', 2, 'http://privatemarket.io/?p=77', 0, 'revision', '', 0),
(78, 1, '2021-12-30 00:37:25', '2021-12-29 23:37:25', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-30 00:37:25', '2021-12-29 23:37:25', '', 2, 'http://privatemarket.io/?p=78', 0, 'revision', '', 0),
(79, 1, '2021-12-30 00:39:31', '2021-12-29 23:39:31', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-30 00:39:31', '2021-12-29 23:39:31', '', 2, 'http://privatemarket.io/?p=79', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(80, 1, '2022-01-01 11:16:46', '2022-01-01 10:16:46', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-01-01 11:16:46', '2022-01-01 10:16:46', '', 2, 'http://privatemarket.io/?p=80', 0, 'revision', '', 0),
(81, 1, '2022-01-01 11:36:55', '2022-01-01 10:36:55', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href="http://privatemarket.io/wp-admin/">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-01-01 11:36:55', '2022-01-01 10:36:55', '', 2, 'http://privatemarket.io/?p=81', 0, 'revision', '', 0),
(82, 1, '2022-01-01 16:08:55', '2022-01-01 15:07:56', '', 'Products', '', 'publish', 'closed', 'closed', '', 'products', '', '', '2022-01-01 16:08:55', '2022-01-01 15:08:55', '', 0, 'http://privatemarket.io/?p=82', 1, 'nav_menu_item', '', 0),
(83, 1, '2022-01-01 16:08:55', '2022-01-01 15:07:56', '', 'Clients', '', 'publish', 'closed', 'closed', '', 'clients', '', '', '2022-01-01 16:08:55', '2022-01-01 15:08:55', '', 0, 'http://privatemarket.io/?p=83', 2, 'nav_menu_item', '', 0),
(84, 1, '2022-01-01 16:08:55', '2022-01-01 15:07:56', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2022-01-01 16:08:55', '2022-01-01 15:08:55', '', 0, 'http://privatemarket.io/?p=84', 3, 'nav_menu_item', '', 0),
(85, 1, '2022-01-01 16:08:55', '2022-01-01 15:07:56', '', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2022-01-01 16:08:55', '2022-01-01 15:08:55', '', 0, 'http://privatemarket.io/?p=85', 4, 'nav_menu_item', '', 0),
(86, 1, '2022-01-01 16:08:55', '2022-01-01 15:07:56', '', 'Request Access', '', 'publish', 'closed', 'closed', '', 'request-access', '', '', '2022-01-01 16:08:55', '2022-01-01 15:08:55', '', 0, 'http://privatemarket.io/?p=86', 5, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(58, 4, 0),
(82, 2, 0),
(83, 2, 0),
(84, 2, 0),
(85, 2, 0),
(86, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 5),
(4, 4, 'wp_theme', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Senza categoria', 'senza-categoria', 0),
(2, 'Primary', 'primary', 0),
(4, 'a5tratto-theme-child', 'a5tratto-theme-child', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_tm_taskmeta`
#

DROP TABLE IF EXISTS `wp_tm_taskmeta`;


#
# Table structure of table `wp_tm_taskmeta`
#

CREATE TABLE `wp_tm_taskmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `task_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_tm_taskmeta`
#

#
# End of data contents of table `wp_tm_taskmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_tm_tasks`
#

DROP TABLE IF EXISTS `wp_tm_tasks`;


#
# Table structure of table `wp_tm_tasks`
#

CREATE TABLE `wp_tm_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `type` varchar(300) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `class_identifier` varchar(300) COLLATE utf8mb4_unicode_520_ci DEFAULT '0',
  `attempts` int(11) DEFAULT '0',
  `description` varchar(300) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_locked_at` bigint(20) DEFAULT '0',
  `status` varchar(300) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_tm_tasks`
#

#
# End of data contents of table `wp_tm_tasks`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'custom-post-type-permalinks-settings'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"de3df70dc0a4d9285ce10ecd5b8b0ffc429c605d2698965b3b7eaabeee7b9d50";a:4:{s:10:"expiration";i:1641204827;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36";s:5:"login";i:1641032027;}s:64:"77b3190c2995b50c91fed8c7e1b22602a3dcfe8d6cb8f4d4ae45ffb7dd1c82c5";a:4:{s:10:"expiration";i:1641292866;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36";s:5:"login";i:1641120066;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(20, 1, 'wp_user-settings', 'libraryContent=browse'),
(21, 1, 'wp_user-settings-time', '1640798666'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(25, 1, 'jetpack_tracks_anon_id', 'jetpack:FpHZ6mdmtJYRKInohr1ugEKa') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BFcHFU7.s15kjQf6VdRlmnqBJOOsUd/', 'admin', 'grgrzz008@gmail.com', 'http://localhost', '2021-12-26 21:37:37', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_520_ci,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_520_ci,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_520_ci,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_title` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT '1',
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'http://privatemarket.io/author/admin/', '37:88af3d67b3f1b95ac55d9095afb1b902', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://1.gravatar.com/avatar/758749a246983533fe19b5aa0a1e1cc2?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://1.gravatar.com/avatar/758749a246983533fe19b5aa0a1e1cc2?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2021-12-29 15:16:21', '2022-01-01 15:09:05', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2021-12-26 21:37:37'),
(2, 'http://privatemarket.io/ciao-mondo/', '35:6795bb526c2212bd33a297fce8dfe7cf', 1, 'post', 'post', 1, 0, NULL, NULL, 'Ciao mondo!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:16:21', '2022-01-02 10:41:12', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-26 21:37:37', '2021-12-26 21:37:37'),
(3, 'http://privatemarket.io/about/', '30:97523437ef4ba5c9df6fc300ad960df1', 9, 'post', 'page', 1, 0, NULL, NULL, 'About', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:16:25', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(4, 'http://privatemarket.io/blog/', '29:eeb104150b831b060fc1b5816c63529a', 10, 'post', 'page', 1, 0, NULL, NULL, 'Blog', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:17:00', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(5, 'http://privatemarket.io/', '24:9341108d2a60827469a73550542145a5', 2, 'post', 'page', 1, 0, NULL, NULL, 'Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2021-12-29 15:18:22', '2022-01-01 10:36:56', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2022-01-01 10:36:55', '2021-12-26 21:37:37'),
(6, 'http://privatemarket.io/cerca/', '30:e086ace0eb5144ea6eda9d51b8692676', 14, 'post', 'page', 1, 0, NULL, NULL, 'Cerca', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:18:22', '2022-01-02 10:41:12', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(7, 'http://privatemarket.io/contatti/', '33:709f36a41014cf0ebefd79f51923e0c1', 11, 'post', 'page', 1, 0, NULL, NULL, 'Contatti', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:18:22', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(8, 'http://privatemarket.io/cookie-policy-gdpr/', '43:e1b41d7bd0cdd27b61a03bef119bcabe', 13, 'post', 'page', 1, 0, NULL, NULL, 'Cookie Policy GDPR', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:18:22', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(9, 'http://privatemarket.io/?page_id=3', '34:d2a98ae454280288e6a137fb149b251c', 3, 'post', 'page', 1, 0, NULL, NULL, 'Privacy Policy', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-12-29 15:18:22', '2021-12-29 15:18:22', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-26 21:37:37', '2021-12-26 21:37:37'),
(10, 'http://privatemarket.io/privacy-policy-gdpr/', '44:0d8fb8909a46e3b16f8ef651955a38fb', 12, 'post', 'page', 1, 0, NULL, NULL, 'Privacy Policy GDPR', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 15:18:22', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:14:28', '2021-12-29 15:14:28'),
(11, 'http://privatemarket.io/?p=23', '29:3f1600ac7bd17073addd5d1c8f98728c', 23, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-12-29 15:18:49', '2021-12-29 15:18:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:18:49', '2021-12-29 15:18:49'),
(12, 'http://privatemarket.io/', '24:9341108d2a60827469a73550542145a5', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', 'Un nuovo sito targato WordPress', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2021-12-29 15:19:00', '2022-01-01 15:09:05', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2021-12-26 21:37:37'),
(13, 'http://privatemarket.io/?p=24', '29:6181d890afdea594bd8ba1cc96a35a70', 24, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-12-29 15:19:01', '2021-12-29 15:19:01', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:19:01', '2021-12-29 15:19:01'),
(16, 'http://privatemarket.io/?p=25', '29:df066623f019bb230e6e107494298a3a', 25, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-12-29 15:19:32', '2021-12-29 15:19:32', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 15:19:32', '2021-12-29 15:19:32'),
(17, 'http://privatemarket.io/?post_type=acf-field-group&p=26', '55:42a987acc7cff950145f001a6461172d', 26, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Page Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 23:40:45', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 23:40:45', '2021-12-29 16:47:15'),
(18, 'http://privatemarket.io/?post_type=acf-field&p=27', '49:b8e6733eef7dabca534b667c042eda7d', 27, 'post', 'acf-field', 1, 26, NULL, NULL, 'Header', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(19, 'http://privatemarket.io/?post_type=acf-field&p=28', '49:a596c1425b0d604b65a8c0706b9f6e19', 28, 'post', 'acf-field', 1, 26, NULL, NULL, 'Header Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(20, 'http://privatemarket.io/?post_type=acf-field&p=29', '49:f937794567d98cf510241b089e5b675d', 29, 'post', 'acf-field', 1, 26, NULL, NULL, 'Header Button', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 23:23:00', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:23:00', '2021-12-29 16:47:15'),
(21, 'http://privatemarket.io/?post_type=acf-field&p=30', '49:3d4a699a2eb163f8abfba5d27aab891f', 30, 'post', 'acf-field', 1, 26, NULL, NULL, 'Plus', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(22, 'http://privatemarket.io/?post_type=acf-field&p=31', '49:a9424d88239ce930d2a5a2446850faca', 31, 'post', 'acf-field', 1, 26, NULL, NULL, 'Plus Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(23, 'http://privatemarket.io/?post_type=acf-field&p=32', '49:51408cc907687eda57d2ca09d33866cc', 32, 'post', 'acf-field', 1, 26, NULL, NULL, 'Featured', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(24, 'http://privatemarket.io/?post_type=acf-field&p=33', '49:4409458798b7b9dc0f7c9fbbffb54051', 33, 'post', 'acf-field', 1, 26, NULL, NULL, 'Featured Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(25, 'http://privatemarket.io/?post_type=acf-field&p=34', '49:4e450ac32893e8446dd69ed6549cb1af', 34, 'post', 'acf-field', 1, 26, NULL, NULL, 'Featureds', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(26, 'http://privatemarket.io/?post_type=acf-field&p=35', '49:5aba6a433a68b50409126e3d2fb79127', 35, 'post', 'acf-field', 1, 34, NULL, NULL, 'Img', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(27, 'http://privatemarket.io/?post_type=acf-field&p=36', '49:4e3560e7e88662c8d3e747cf5f17f944', 36, 'post', 'acf-field', 1, 26, NULL, NULL, 'ADV', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(28, 'http://privatemarket.io/?post_type=acf-field&p=37', '49:bab3d68740562fad01131517bf4fc73d', 37, 'post', 'acf-field', 1, 26, NULL, NULL, 'Investors Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(29, 'http://privatemarket.io/?post_type=acf-field&p=38', '49:72892ac176b12972c4f97bb31b6b0587', 38, 'post', 'acf-field', 1, 26, NULL, NULL, 'Investors', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(30, 'http://privatemarket.io/?post_type=acf-field&p=39', '49:f361cb331cdeb294dfb753ed0ea24974', 39, 'post', 'acf-field', 1, 38, NULL, NULL, 'Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(31, 'http://privatemarket.io/?post_type=acf-field&p=40', '49:05ca0e1da14777b104ad37d2900d2fe4', 40, 'post', 'acf-field', 1, 26, NULL, NULL, 'Found', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(32, 'http://privatemarket.io/?post_type=acf-field&p=41', '49:8ec94b789dff75573189eee2b9df8e0b', 41, 'post', 'acf-field', 1, 26, NULL, NULL, 'Founds Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(33, 'http://privatemarket.io/?post_type=acf-field&p=42', '49:253344b43dd98bbe16479756e7d4b8e4', 42, 'post', 'acf-field', 1, 26, NULL, NULL, 'Founds', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(34, 'http://privatemarket.io/?post_type=acf-field&p=43', '49:3e5db4664c0e0fd1d4c0cccc81b865a4', 43, 'post', 'acf-field', 1, 42, NULL, NULL, 'Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:47:15', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:47:15', '2021-12-29 16:47:15'),
(35, 'http://privatemarket.io/?post_type=acf-field&p=44', '49:e3f9052290e3b7444b976f5c2e749898', 44, 'post', 'acf-field', 1, 26, NULL, NULL, 'Tech', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(36, 'http://privatemarket.io/?post_type=acf-field&p=45', '49:5b2d2ca30da8989e6e46ddb9c71a9027', 45, 'post', 'acf-field', 1, 26, NULL, NULL, 'Tech Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(37, 'http://privatemarket.io/?post_type=acf-field&p=46', '49:4676d3da9b5294a221e9c1dacf2a978b', 46, 'post', 'acf-field', 1, 26, NULL, NULL, 'Technology', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 23:40:45', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:40:45', '2021-12-29 16:47:15'),
(38, 'http://privatemarket.io/?post_type=acf-field&p=47', '49:9bd79afce72c8a1c162b15e044afa1b1', 47, 'post', 'acf-field', 1, 46, NULL, NULL, 'Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:47:15', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:47:15'),
(39, 'http://privatemarket.io/?post_type=acf-field&p=48', '49:072291ebc35adb4fd9c0bfd8dccf3ed3', 48, 'post', 'acf-field', 1, 26, NULL, NULL, 'Tech Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(40, 'http://privatemarket.io/?post_type=acf-field&p=49', '49:f78f9319346337d5c2cf531bf3cfd065', 49, 'post', 'acf-field', 1, 46, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 23:40:45', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:40:45', '2021-12-29 16:49:46'),
(41, 'http://privatemarket.io/?post_type=acf-field&p=50', '49:cb7bba8479d8544b707c5ab13934a5b3', 50, 'post', 'acf-field', 1, 46, NULL, NULL, 'Img', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(42, 'http://privatemarket.io/?post_type=acf-field&p=51', '49:f72f4a633c7d5892a916352e9cadc7ab', 51, 'post', 'acf-field', 1, 26, NULL, NULL, 'Partner', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(43, 'http://privatemarket.io/?post_type=acf-field&p=52', '49:ec5b02083a87345ff18d58670959656d', 52, 'post', 'acf-field', 1, 26, NULL, NULL, 'Partner Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(44, 'http://privatemarket.io/?post_type=acf-field&p=53', '49:e734455656084d4c24456dc67e423e6f', 53, 'post', 'acf-field', 1, 26, NULL, NULL, 'Partners', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(45, 'http://privatemarket.io/?post_type=acf-field&p=54', '49:78c898e657d062b04c7a4ca11f827fe2', 54, 'post', 'acf-field', 1, 53, NULL, NULL, 'Img', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:49:46', '2021-12-29 16:49:46', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:49:46', '2021-12-29 16:49:46'),
(46, 'http://privatemarket.io/?post_type=acf-field&p=55', '49:8251ba0e1a5fdfbf28bb2f7b9a9ae4ca', 55, 'post', 'acf-field', 1, 26, NULL, NULL, 'Contact', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:50:45', '2021-12-29 16:50:45', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 16:50:45', '2021-12-29 16:50:45'),
(47, 'http://privatemarket.io/?post_type=acf-field&p=56', '49:e7ebe44edbb90756aa249d98daabd5a6', 56, 'post', 'acf-field', 1, 26, NULL, NULL, 'Contact Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:50:45', '2021-12-29 16:50:45', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:50:45', '2021-12-29 16:50:45'),
(48, 'http://privatemarket.io/?post_type=acf-field&p=57', '49:bb94e28f6ee7b28fa6700b55ec71cb25', 57, 'post', 'acf-field', 1, 26, NULL, NULL, 'Contact Button', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 16:50:45', '2021-12-29 16:50:45', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 16:50:45', '2021-12-29 16:50:45'),
(49, 'http://privatemarket.io/wp-global-styles-a5tratto-theme-child/', '62:d3824f86911cfd7b5e7d51319913cead', 58, 'post', 'wp_global_styles', 1, 0, NULL, NULL, 'Custom Styles', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2021-12-29 17:21:18', '2021-12-29 17:21:18', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-29 17:21:18', '2021-12-29 17:21:18'),
(50, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj.png', '59:d8e84054af0f3981873069109d914bee', 59, 'post', 'attachment', 1, 2, NULL, NULL, 'avcj', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj.png', NULL, '59', 'attachment-image', NULL, NULL, NULL, '59', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 17:24:14', '2021-12-29 17:24:14', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 17:24:14', '2021-12-29 17:24:14'),
(51, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine.png', '70:9c6d08dd50a1a9cb181c08c343fca10c', 60, 'post', 'attachment', 1, 2, NULL, NULL, 'bitcoinmagazine', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine.png', NULL, '60', 'attachment-image', NULL, NULL, NULL, '60', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 17:24:16', '2021-12-29 17:24:16', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 17:24:16', '2021-12-29 17:24:16'),
(52, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire.png', '67:95429cc8cddbcfd7d8a106e5a2f9fb38', 61, 'post', 'attachment', 1, 2, NULL, NULL, 'businesswire', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire.png', NULL, '61', 'attachment-image', NULL, NULL, NULL, '61', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 17:24:18', '2021-12-29 17:24:18', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 17:24:17', '2021-12-29 17:24:17'),
(53, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn.png', '58:e4a8bbf49b5c9de6acf0a6e29241ae38', 62, 'post', 'attachment', 1, 2, NULL, NULL, 'cnn', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn.png', NULL, '62', 'attachment-image', NULL, NULL, NULL, '62', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 17:24:19', '2021-12-29 17:24:19', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 17:24:19', '2021-12-29 17:24:19'),
(54, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra.png', '63:65117d2d4e70d5f586d8a62f8d5f720e', 63, 'post', 'attachment', 1, 2, NULL, NULL, 'finextra', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra.png', NULL, '63', 'attachment-image', NULL, NULL, NULL, '63', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 17:24:21', '2021-12-29 17:24:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 17:24:21', '2021-12-29 17:24:21'),
(55, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj-1.png', '61:6dbaf387e9e1b824a89f4668f465dbf8', 66, 'post', 'attachment', 1, 2, NULL, NULL, 'avcj', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/avcj-1.png', NULL, '66', 'attachment-image', NULL, NULL, NULL, '66', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:17:44', '2021-12-29 23:17:44', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:17:44', '2021-12-29 23:17:44'),
(56, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine-1.png', '72:8ff435e3f620ea31260195a36126ddab', 67, 'post', 'attachment', 1, 2, NULL, NULL, 'bitcoinmagazine', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/bitcoinmagazine-1.png', NULL, '67', 'attachment-image', NULL, NULL, NULL, '67', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:17:46', '2021-12-29 23:17:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:17:46', '2021-12-29 23:17:46'),
(57, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire-1.png', '69:df229660d34c0ae1ab20f7fc1f88aee6', 68, 'post', 'attachment', 1, 2, NULL, NULL, 'businesswire', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/businesswire-1.png', NULL, '68', 'attachment-image', NULL, NULL, NULL, '68', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:17:48', '2021-12-29 23:17:48', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:17:48', '2021-12-29 23:17:48'),
(58, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn-1.png', '60:f4e933788c61963bbd461a0a1c2391df', 69, 'post', 'attachment', 1, 2, NULL, NULL, 'cnn', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/cnn-1.png', NULL, '69', 'attachment-image', NULL, NULL, NULL, '69', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:17:49', '2021-12-29 23:17:49', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:17:49', '2021-12-29 23:17:49'),
(59, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra-1.png', '65:18e5d8c429bebc4230e6c3302e3ba45a', 70, 'post', 'attachment', 1, 2, NULL, NULL, 'finextra', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/finextra-1.png', NULL, '70', 'attachment-image', NULL, NULL, NULL, '70', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:17:51', '2021-12-29 23:17:51', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:17:51', '2021-12-29 23:17:51'),
(60, 'http://privatemarket.io/wp-content/uploads/2021/12/box1.png', '59:f1d7c5c29a4ae7496864509692494c9f', 71, 'post', 'attachment', 1, 2, NULL, NULL, 'box1', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/box1.png', NULL, '71', 'attachment-image', NULL, NULL, NULL, '71', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:19:50', '2021-12-29 23:19:50', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:19:50', '2021-12-29 23:19:50'),
(61, 'http://privatemarket.io/wp-content/uploads/2021/12/box2.png', '59:9a368a09ab0afa124cb19a455f3f08d7', 72, 'post', 'attachment', 1, 2, NULL, NULL, 'box2', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/box2.png', NULL, '72', 'attachment-image', NULL, NULL, NULL, '72', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:19:56', '2021-12-29 23:19:56', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:19:56', '2021-12-29 23:19:56'),
(62, 'http://privatemarket.io/wp-content/uploads/2021/12/box3.png', '59:2ee9fe624b4142e6cf1cb776da6eebbe', 73, 'post', 'attachment', 1, 2, NULL, NULL, 'box3', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/box3.png', NULL, '73', 'attachment-image', NULL, NULL, NULL, '73', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:20:04', '2021-12-29 23:20:04', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:20:04', '2021-12-29 23:20:04'),
(63, 'http://privatemarket.io/wp-content/uploads/2021/12/box4.png', '59:e0bedaec73b4dde5b790b93463447266', 74, 'post', 'attachment', 1, 2, NULL, NULL, 'box4', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://privatemarket.io/wp-content/uploads/2021/12/box4.png', NULL, '74', 'attachment-image', NULL, NULL, NULL, '74', 'attachment-image', NULL, NULL, NULL, NULL, '2021-12-29 23:20:12', '2021-12-29 23:20:12', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2021-12-29 23:20:12', '2021-12-29 23:20:12'),
(64, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-01-01 12:08:47', '2022-01-01 12:08:47', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(65, 'http://privatemarket.io/products/', '33:850e4258d43415596c47907edc671c05', 82, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Products', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-01 15:07:07', '2022-01-01 15:08:55', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2022-01-01 15:07:56'),
(66, 'http://privatemarket.io/clients/', '32:48d5dadad58c73840b0029f92b37ab7e', 83, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Clients', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-01 15:07:20', '2022-01-01 15:08:55', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2022-01-01 15:07:56'),
(67, 'http://privatemarket.io/about-us/', '33:0fcde31983577de837a7bd7360e2551f', 84, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'About Us', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-01 15:07:30', '2022-01-01 15:08:55', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2022-01-01 15:07:56'),
(68, 'http://privatemarket.io/login/', '30:1c087632df03d0c619ad4e9fc4f9fa98', 85, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Login', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-01 15:07:40', '2022-01-01 15:08:55', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2022-01-01 15:07:56'),
(69, 'http://privatemarket.io/request-access/', '39:3977d587d6382a886998c886f22fac92', 86, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Request Access', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-01 15:07:53', '2022-01-01 15:08:55', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-01-01 15:08:55', '2022-01-01 15:07:56'),
(70, 'http://privatemarket.io/category/senza-categoria/', '49:195e8bcbc74e40ad31cb4d32a4293463', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Senza categoria', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-01-02 10:41:07', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2021-12-26 21:37:37', '2021-12-26 21:37:37'),
(71, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-01-02 10:41:07', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(72, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-01-02 10:41:07', '2022-01-02 10:41:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(1, 0, 0, 1),
(2, 0, 0, 1),
(3, 0, 0, 1),
(4, 0, 0, 1),
(5, 0, 0, 1),
(8, 0, 0, 1),
(10, 0, 0, 1),
(11, 0, 0, 1),
(12, 0, 0, 1),
(13, 0, 0, 1),
(16, 0, 0, 1),
(17, 0, 0, 1),
(20, 17, 1, 1),
(24, 17, 1, 1),
(25, 17, 1, 1),
(27, 17, 1, 1),
(28, 17, 1, 1),
(29, 17, 1, 1),
(31, 17, 1, 1),
(32, 17, 1, 1),
(33, 17, 1, 1),
(35, 17, 1, 1),
(36, 17, 1, 1),
(37, 17, 1, 1),
(38, 17, 2, 1),
(38, 37, 1, 1),
(40, 17, 2, 1),
(40, 37, 1, 1),
(64, 0, 0, 1),
(65, 0, 0, 1),
(66, 0, 0, 1),
(67, 0, 0, 1),
(68, 0, 0, 1),
(69, 0, 0, 1) ;

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_primary_term`
#

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(1, 'http://privatemarket.io/wp-admin/', 2, NULL, 'internal', 5, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

